function v = MatlabMPI_ver
%MATLAB_MPI Returns the MatlabMPI version as a string

v = '1.2br2';
