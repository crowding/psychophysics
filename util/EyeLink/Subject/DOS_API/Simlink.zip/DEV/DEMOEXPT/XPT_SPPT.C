/* EYELINK PORTABLE EXPT SUPPORT    */
/* (c) 1996-1998, SR Research Ltd.  */
/*     8 June '97 by Dave Stampe    */
/*     For non-commercial use only  */
/*				    */
/*  formatted link printf           */
/*  Recording and trial support	    */

/* This module is for user applications   */
/* Use is granted for non-commercial      */
/* applications by Eyelink licencees only */

/************** WARNING **************/
/*                                   */
/* UNDER NO CIRCUMSTANCES SHOULD     */
/* PARTS OF THESE FILES BE COPIED OR */
/* COMBINED.  This will make your    */
/* code impossible to upgrade to new */
/* releases in the future, and       */
/* SR Research will not give tech    */
/* support for reorganized code.     */
/*                                   */
/* This file should not be modified. */
/* If you must modify it, copy the   */
/* entire file with a new name, and  */
/* change the the new file.          */
/*                                   */
/************** WARNING **************/


#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include "eyelink.h"
#include "exptsppt.h"


/****** FORMATTED COMMAND SEND **********/

INT16 eyecmd_printf(char *fmt, ...)
{
  va_list argptr;
  char cmdbuf[200];
  int i;

  va_start(argptr, fmt);
  vsprintf(cmdbuf, fmt, argptr);
  va_end(argptr);

  i = eyelink_timed_command(1000, cmdbuf);
  return i;
}


/********* FORMATTED DATA-FILE MESSAGES **********/

	/* This allows us to send messages to the Eyelink tracker */
	/* to be logged into the data file. */
	/* Use it just like printf() to format the message text. */
	/* RETURNS: 0 if OK, else error code */

INT16 eyemsg_printf(char *fmt, ...)
{
  va_list argptr;
  char msgbuf[200];
  int i;

  va_start(argptr, fmt);
  vsprintf(msgbuf, fmt, argptr);
  va_end(argptr);

  i = eyelink_send_message(msgbuf);
  return i;
}

/********* EDF OPEN, CLOSE ************/

// These functions were added as future revisions of EyeLink
// might require significant time to open and close EDF files

	// Opens EDF file on tracker hard disk
	// Returns 0 if success, else error code
INT16 open_data_file(char *name)
{
  char s[100];
  
  strcpy(s, "open_data_file '");
  strcat(s, name);
  strcat(s, "'");
  return eyelink_timed_command(10000, s);
}

	// Closes EDF file on tracker hard disk
	// Returns 0 if success, else error code
INT16 close_data_file(void)
{
  return eyelink_timed_command(10000, "close_data_file");
}

/********* HANDLE ABORT MENU FOR TRIAL  *******/

#define DONE_TRIAL   0  /* return codes for trial result */

#define REPEAT_TRIAL 1
#define SKIP_TRIAL   2
#define ABORT_EXPT   3

#define TRIAL_ERROR  -1 /* Bad trial: no data, etc. */


	/* If the trial is aborted (CTRL-ALT-A on the tracker) */
	/* we go to user menu 1.  This lets us perform a setup, */
	/* repeat this trial, skip the trial or quit. */

	/* Requires the user menu 1 (Abort) to be set up */
	/* on tracker (the default is preset in KEYS.INI). */

	/* RETURNS: One of REPEAT_TRIAL, SKIP_TRIAL, ABORT_EXPT. */

INT16 record_abort_handler(void)
{
  int i;
  int key;
			/* We only get here if we're already in the menu */
  record_abort_hide();
  while(1)		/* we will only exit if we have a menu response */
    {
      key = getkey();		/* HANDLE LOCAL KEY PRESS */
      switch(key)
	{
	  case 0: 		/* No key */
	  case JUNK_KEY: 	/* No key */
	    break;
	  case TERMINATE_KEY:   /* breakout key */
	    eyelink_abort();    /* this cleans up by erasing menu */
	    return ABORT_EXPT;
	  default:              /* Echo to tracker for remote control */
	    if(allow_local_control)
		eyelink_send_keybutton(key,0,KB_PRESS);
	    break;
	}

      i = eyelink_current_mode();
      if(i & IN_DISCONNECT_MODE) return ABORT_EXPT;  /* Whoops! lost link */

				/* the menu can call SETUP menu, */
				/* so we support it here */
      if(i & IN_TARGET_MODE)
	 target_mode_display(); /* show targets during setup */

      else if(i & IN_IMAGE_MODE)
	{
	  image_mode_display();     /* camera image display */
	}


      else if(i & IN_USER_MENU)     /* handle user menu selections */
	{
	  switch(eyelink_user_menu_selection())
	    {
	      case 1:      	 /* SETUP selected */
		break;   	 /* (menu command starts mode so we ignore) */
	      case 2:		 /* REPEAT trial */
		return REPEAT_TRIAL;
	      case 3:		 /* NEXT   trial */
		return SKIP_TRIAL;
	      case 4:		     /* ABORT  experiment */
		eyelink_abort();     /* this cleans up by erasing menu */
		return ABORT_EXPT;
	      default:		     /* no selection: continue */
		break;
	    }
	}
      else if(!(i & IN_SETUP_MODE)) 	/* If not a mode we want to be in: */
	{                           	/* FORCE back to menu mode */
	  eyelink_timed_command(500,"display_user_menu 1");
	}
    }
}


/*********** RECORDING SUPPORT FUNCTIONS ************/

	/* check if we are recording: if not, report an error */
INT16 check_recording(void)
{
  int i = eyelink_is_connected();

  if(i==0) return ABORT_EXPT;	// disconnected
  if(i==-1) return 0;           // dummy connected

			      /* are we still recording? */
  if(eyelink_current_mode() & IN_RECORD_MODE) return 0;

				   /* Was it an abort to Abort Menu? */
  if(eyelink_current_mode() & IN_USER_MENU)
    {                              /* handle abort menu */
      eyecmd_printf("heuristic_filter = ON");
      eyemsg_printf("TRIAL ABORTED");
      return record_abort_handler();
    }
  else
    {
      eyecmd_printf("heuristic_filter = ON");
      eyelink_abort();             /* other error: go to offline mode */
      eyelink_wait_for_mode_ready(500);
      return TRIAL_ERROR;
    }
}

       /* halt recording, wait till finished mode switch */
void stop_recording(void)
{
  eyecmd_printf("heuristic_filter = ON");
  eyelink_abort();
  eyelink_wait_for_mode_ready(500);
}

       /* enter tracker idle mode, wait till finished mode switch */
void set_offline_mode(void)
{
  eyelink_abort();
  eyelink_wait_for_mode_ready(500);
}

       /* check if we are in Abort menu after recording stopped */
       /* returns trial exit code                               */
INT16 check_record_exit(void)
{
			   /* HANDLE SPECIAL EXIT CONDITIONS */
  if(eyelink_current_mode() & IN_USER_MENU)
    {
      return record_abort_handler();	/* did we abort out?  Handle it! */
    }
  else return DONE_TRIAL;		/* Good exit */
}

       /* Start recording with data types requested      */
       /* Check that all requested link data is arriving */
       /* return 0 if OK, else trial exit code           */
INT16 start_recording(INT16 file_samples, INT16 file_events,
		    INT16 link_samples, INT16 link_events)
{
  UINT32 t;
  int i = eyelink_is_connected();

  if(i==0) return ABORT_EXPT;	// disconnected
  if(i==-1) return 0;           // dummy connected

  i = eyelink_data_start( (file_samples?RECORD_FILE_SAMPLES:0) |
			  (file_events?RECORD_FILE_EVENTS:0)   |
			  (link_samples?RECORD_LINK_SAMPLES:0) |
			  (link_events?RECORD_LINK_EVENTS:0) , 1);
  if(i) return i;
  i = eyelink_wait_for_mode_ready(500);  /* wait for mode change completion */
  if(i==0) return TRIAL_ERROR;
  if((i=check_recording())!=0) return i;  /* check that recording started OK */
  if(eyelink_is_connected() < 0) return 0;		// dummy connect

  t = current_time()+300L;
  while(t > current_time())
    {
      int done = 1;

      if((i=check_recording())!=0) return i;  /* check that recording still OK */

      if(link_samples)			      /* check for ALL data types */
	 if(eyelink_data_count(1,0)==0) done = 0;
      if(link_events)
	 if(eyelink_data_count(0,1)==0) done = 0;
      if(done) return 0;
    }
  stop_recording();	/* timeout: exit */
  return TRIAL_ERROR;
}

