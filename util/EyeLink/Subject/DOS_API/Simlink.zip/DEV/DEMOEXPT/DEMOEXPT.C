/*  SAMPLE EXPERIMENT USING EYELINK SIMTSR FOR DOS */
/*  13 December 1997 by Dave Stampe                */
/*  Copyright (c) 1996-1998 SR Research Ltd.       */

/*   This file can serve as a start       */
/*   for programming most experiments     */

/* This file: MAIN for experiment: open link, run trials, close link */
/* In a real experiment, this file would also control randomization. */
/* Code for sequencing trials and executing trials is in other files */

#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <dos.h>
#include <string.h>

#include "eyelink.h"
#include "exptsppt.h"

#include "demoexpt.h"  /* header file for this experiment */


/********* CLOSE LINK, RESET TRACKER ********/

int system_initialized = 0;	/* 1 if link has been opened */

void shutdown_system(void)
{
  reset_graphics(); 		/* return to text mode screen */
  if(!system_initialized) return;

  if(eyelink_is_connected())
    {
      set_offline_mode();       /* off-line mode */
      eyelink_send_command("close_data_file"); /* close, but don't wait */
      msec_delay(500);
      eyelink_close(1);         /* disconnect from tracker */
    }
  close_eyelink_system();       /* release TSR */

  system_initialized = 0;       /* make sure we don't loop */
}



/****** INITIALIZE EYE TRACKER CONNECTION ******/


	/* Initialize SIMLINK and Ethernet system */
	/* Opens connection, report any problems */
	/* RETURNS: 0 if OK, -1 if error */

int initialize_system(int dummy)
{
  int i;

  if(!open_eyelink_system(20000, ""))
    {
      printf("\nERROR: TSR NOT LOADED\n");
      return -1;
    }

  printf("Connecting to eye tracker...\n");
  if(dummy)
    i = eyelink_dummy_open();
  else
    i = eyelink_open();

  if(i != 0)
    {
      if(i==CONNECT_TIMEOUT_FAILED)
	  printf("\nERROR: Connect timed out.\n");
      else if(i==WRONG_LINK_VERSION)
	  printf("\nERROR: Wrong TSR version for EYELINK tracker software.\n");
      else if(i==LINK_INITIALIZE_FAILED)
	  printf("\nERROR: Cannot initialize link.\n");
      return -1;
    }
  system_initialized = 1;

  set_error_traps(0);
  atexit(shutdown_system);

  msec_delay(15);
  return 0;
}



/*********** RUN EXPERIMENT **********/


int main()
{
  int i;
			/* DATA FILE NAME (preset for this example) */
			/* in a real experiment, we would prompt for it */
			/* or get it from the command line. */
  char our_file_name[20] = "data.edf";

				/* INITIALIZE SYSTEM */
  if(initialize_system(0))	/* Set up, open link to tracker */
    {
      printf("Error in initialization\n");
      exit(-1);
    }

  printf("\nEDF File name?: ");
  gets(our_file_name);


		/* CREATE OUR DATA FILE */
		/* add one line to preamble to identify experiment */
  if(our_file_name[0])
    {
      if(!strstr(our_file_name,".")) strcat(our_file_name, ".edf");
      i = open_data_file(our_file_name);
      if(i!=0) goto end_expt;
      eyecmd_printf("add_file_preamble_text 'RECORDED BY DEMO.EXE'");
    }

  if(init_graphics()) goto end_expt; /* set up 640x480, 16 color VGA mode */
				     /* set calibration type */
				     /* also sets up for display resolution */
  eyecmd_printf("calibration_type = HV9");

  target_foreground_color = 0;   /* target display color */
  target_background_color = 7;  /* calibration screen color */


		/* SET UP TRACKER CONFIGURATION */
				/* set parser (conservative saccade thresholds) */
  eyecmd_printf("saccade_velocity_threshold = 35");
  eyecmd_printf("saccade_acceleration_threshold = 9500");
			       /* set EDF file contents */
  eyecmd_printf("file_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,MESSAGE,BUTTON");
			       /* set link data (if used for gaze cursor) */
  eyecmd_printf("link_event_filter = LEFT,RIGHT,FIXATION,BUTTON");
  eyecmd_printf("link_sample_data  = LEFT,RIGHT,GAZE,AREA");

		/* In a multi-block experiment, we would */
		/* probably have a loop here performing */
		/* a setup and a set of trials */
		/* for each block.  The error code */
		/* in i would be used to abort the experiment. */

  if(!eyelink_is_connected()) goto end_expt;

		/* RUN THE TRIALS */
  i = run_trials();

		/* CLEANUP AND SHUT DOWN */
end_expt:
  reset_graphics(); 	/* return to text mode screen */


  set_offline_mode();   /* off-line mode for file transfer */
  close_data_file();	/* close data file */
  if(our_file_name[0])
    receive_data_file(our_file_name, our_file_name, 0); /* copy it to local PC */

  msec_delay(500);	/* give tracker time to execute all commands */
  shutdown_system();    /* cleanup and exit */

  return 0;
}


