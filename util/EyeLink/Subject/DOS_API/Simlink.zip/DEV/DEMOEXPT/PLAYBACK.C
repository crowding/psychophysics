/*  SAMPLE EXPERIMENT USING EYELINK SIMTSR FOR DOS */
/*  13 December 1997 by Dave Stampe                */
/*  Copyright (c) 1996-1998 SR Research Ltd.       */

/* This file: Play back data from last trial */

#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <string.h>

#include "eyelink.h"

#include "exptsppt.h"

#include "demoexpt.h"  /* header file for this experiment */

#if (defined(__BORLANDC)||defined(__TURBOC__))
  #define TEXTPOSN(r,c) gotoxy(r,c)
#else
  #define TEXTPOSN(c,r) _settextposition(r,c)
#endif


/******* SIMPLE DISPLAY OF GAZE, FIXATIONS *******/

     /* this very simple demo uses characters drawn on screen */
     /* to plot gaze position and fixations.                  */
     /* this method lets this file be is compiler independent */

static int old_gazex;	/* character position of old gaze plot */
static int old_gazey;

	  /* erase gaze plot by printing blank */
static void erase_gazepos(void)
{
  TEXTPOSN(old_gazex, old_gazey);
  printf("�");
}

	 /* plot gaze position with box character */
static void show_gazepos(int x, int y)
{
  x = x/8;          	 /* compute position on 80x50 grid */
  y = y/8;
  if(x<0 || x>79) return;        /* not drawn if off screen */
  if(y<0 || y>49) return;
  old_gazex = x + 1;             /* compute character position */
  old_gazey = y/2 + 1;
  TEXTPOSN(old_gazex, old_gazey);
  if(y&1)
    printf("�");
  else
    printf("�");
}

	 /* plot fixation position with "F" */
static void show_fixpos(int x, int y)
{
  x = x/8;          	 /* compute position on 80x25 grid */
  y = y/16;
  if(x<0 || x>79) return;        /* not drawn if off screen */
  if(y<0 || y>24) return;
  TEXTPOSN(x, y);
  printf("F");
}


/********* PLAYBACK TRIAL DATA  *******/



int playback_trial(void)
{
  int i;
  ALLF_DATA evt;	/* buffer for samples and events */
  int eye_used;		/* eye's data used for plotting */
  float x, y;		/* gaze position */

  clear_display(target_background_color); /* clear display */
  TEXTPOSN(20,1);
  printf(" Playing back last trial ");

	    /* Start data playback of last trial      */
	    /* This requires that an EDF file be open */
	    /* We wait for data to arrive to confirm. */
  set_offline_mode();
  if( eyelink_playback_start()) return -1;
  if(!eyelink_wait_for_data(2000, 1, 1) ) return -1;

  eye_used = -1;	/* we don't know which eye yet */

  eyelink_flush_keybuttons(0);   /* reset keys and buttons from tracker */
  while(getkey());		 /* dump any pending local keys */

  while(1)          /* loop till data done or key pressed */
    {
		    /* if ESC key or button pressed, stop playback */
      if(getkey()==ESC_KEY) break;
      if(eyelink_last_button_press(NULL)) break;

		    /* check for data available */
      i = eyelink_get_next_data(NULL);

      if(i==0)      /* if none, is playback finished? */
	if((eyelink_current_mode() & IN_PLAYBACK_MODE)==0) break;

			/* PLOT FIXATIONS */
      if(i == ENDFIX)	/* check for a fixation event */
	{
	  eyelink_get_float_data(&evt);   /* get copy of it */
	  if(evt.fe.eye == eye_used)	  /* is it same eye as gaze cursor? */
	    {                             /* show average position */
	      show_fixpos(evt.fe.gavx, evt.fe.gavy);
	    }
	}
				/* MOVE GAZE PLOT */
      else if(i == SAMPLE_TYPE) /* check for sample data */
	{
	  msec_delay(3);	/* for close to real-time speed */
	  eyelink_get_float_data(&evt);  /* get the sample */
	    {
	      if(eye_used == -1)   /* need to determine which eye */
		{
		  eye_used = eyelink_eye_available();
		  if(eye_used==BINOCULAR) eye_used = LEFT_EYE;
		}
	      else
		{
		  x = evt.fs.gx[eye_used];       /* get gaze position from sample */
		  y = evt.fs.gy[eye_used];
		  if(x!=MISSING_DATA || y!=MISSING_DATA)  /* pupil visible? */
		    {
		      erase_gazepos();     /* move gaze position */
		      show_gazepos(x,y);
		    }
		  else
		    {
		      erase_gazepos();     /* just hide if in blink */
		    }
		}
	    }
	}
    }
  eyelink_playback_stop();
  TEXTPOSN(20,2);
  printf(" Playback done: Press a key to exit ");
  while(1)
    {
      if(getkey()) break;
      if(eyelink_last_button_press(NULL)) break;
    }
  return 0;
}


