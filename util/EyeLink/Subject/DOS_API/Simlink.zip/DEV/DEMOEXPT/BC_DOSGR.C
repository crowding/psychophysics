/*  MS-DOS EYELINK PROGRAMMING         */
/*  (c) 1997, 1998 by SR Research Ltd. */
/*  17 December 1997 by Dave Stampe    */

/* This file: basic graphics support (640x480, 16 colors)     */
/* Camera image displayed using Mode 13h (320x200x256 colors) */
/* Borland C  specific graphics support                       */

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <dos.h>
#include <string.h>

#include <graphics.h>
#include "eyelink.h"
#include "exptsppt.h"

INT16 target_background_color = 7;
INT16 target_foreground_color = 0;


/*********** BORLAND C GRAPHICS SUPPORT ********/

INT16 graphics_set = 0;	/* have we initialized graphics? */
int current_gmode;	/* BGI mode for restoration */

		/* reset, cleanup, return to text mode */
void reset_graphics(void)
{
  if(!graphics_set) return;

  erase_cal_target();
  closegraph();
  graphics_set = 0;
}

		/* Setup graphics */
		/* This should enter graphics mode */
		/* BORLAND C SPECIFIC */
INT16 init_graphics(void)
{
  int gdriver = VGA;
  int gmode = VGAHI;

  if(graphics_set) return 1;

  registerbgidriver(EGAVGA_driver);  /* This assumes LINKED egavga.obj */

  initgraph(&gdriver, &gmode, "");
  current_gmode = getgraphmode();

	     /* TELL TRACKER OUR MODE RESOLUTION */
  eyecmd_printf("screen_pixel_coords = 0, 0, 640, 480");
	     /* place in data file as well */
  eyemsg_printf("DISPLAY_COORDS  0  0  640  480");

  atexit(reset_graphics);
  graphics_set = 1;
  return 0;
}


	  /* restore 640x480 after image display */
	  /* BORLAND C SPECIFIC */
void reinit_graphics(void)
{
  setgraphmode(current_gmode);
}


	  /* enter VGA 320x200, 256 color mode */
	  /* COMPILER NONSPECIFIC */
void set_image_graphics(void)
{
  union REGS r;

  _asm mov ax, 0x0013;
  _asm int 0x10;
}


/*************** WAIT FOR VGA RETRACE **********/

	/* Use this routine to wait for start of display scan */
	/* This will reduce uncertainty when stimuli become visible. */
void vga_retrace_wait(void)
{
  unsigned addr = (inportb(0x3cc)&0x01) ? 0x3DA : 0x3BA;  /* where's IS reg? */

  while(1)		/* wait for end of retrace */
    {
      if(inportb(addr) & 0x08) break;
    }
  while(1)		/* wait for start of retrace */
    {
      if((inportb(addr) &0x08)==0) break;
    }
}



/******* CALIBRATION TARGET *******/

static int old_cal_x = -1;   /* remember target position for erase */
static int old_cal_y = -1;


	/* Erase calibration target: */
	/* just draws over it in target_background_color */
	/* BORLAND C SPECIFIC */
void erase_cal_target(void)
{
  if(!graphics_set) return;
  if(old_cal_x == -1) return;
  setfillstyle(SOLID_FILL, target_background_color);
  bar(old_cal_x-8,old_cal_y-8,old_cal_x+8,old_cal_y+8);
  old_cal_x = -1;
}


	/* Draw calibration target: Disk with hole in middle */
	/* Uses target_foreground_color and target_background_color */
	/* BORLAND C SPECIFIC */
void draw_cal_target(INT16 x, INT16 y)
{
  if(!graphics_set) return;

  old_cal_x = x;		/* remember positon for erase */
  old_cal_y = y;

  setcolor(target_foreground_color);
  setfillstyle(SOLID_FILL, target_foreground_color);
  fillellipse(x, y, 5, 5);
  setfillstyle(SOLID_FILL, target_background_color);
  fillellipse(x ,y, 2, 2);
}

/********** CLEAR DISPLAY FOR CALIBARATION *************/

		/* Called to clear display for calibration */
		/* and drift correction displays */
		/* Also called if recording aborted from tracker. */
void clear_display(INT16 color)
{
		/* we have to go direct to VGA for this */
		/* because graphics library can't clear to color */
  outport(0x3C4,0x0F02);   /* select planes to write */
  outport(0x3CE,0x0005);   /* set write mode 0 	     */
  outport(0x3CE,0x0F01);   /* set ESR for all bits   */
  outport(0x3CE,0xFF08);   /* all pixels             */

  outportb(0x3CE,0);
  outportb(0x3CF,color);   /* set color */

  _fmemset(MK_FP(0xA000,0), 0U, 80U*480U);

  outport(0x3CE,0x0001);   /* restore standard ESR    */
}



/********* CALIBRATION DISPLAY (EXPTSPPT FUNCTIONS) ***********/

	/* sets up display for calibration */
	/* may be called repeatedly, just clear screen if window exists */
	/* return -1 if fails, else 0 */
INT16 setup_cal_display(void)
{
  clear_display(target_background_color);
  return 0;
}

	/* Clear calibration display, used by drift correction and calibration */
void clear_cal_display(void)
{
  clear_display(target_background_color);
}


	/* end of setup: cleanup calibration display */
void exit_cal_display(void)
{
  clear_cal_display();
}

/********* CALIBRATION BEEPS (EXPTSPPT FUNCTIONS) *********/

  // speaker beeps, included as MSC does not have routine

static void dos_sound(long freq)
{
  long div = 1193180L/freq;

  outportb(0x43, 0xB6);
  outportb(0x42, (unsigned char)(div&255));
  outportb(0x42, (unsigned char)((div>>8)&255));
  outportb(0x61, inp(0x61)|0x03);
}

static void dos_nosound(void)
{
  outportb(0x61, inp(0x61)&0xFC);
}

void cal_done_beep(INT16 error)	 /* used to signal end: <error> nonzero if problem */
{
  if(error==-1)  dos_sound(440);        // error
  else if(error==0)  dos_sound(1000);   // good calibration
  else if(error==1)  dos_sound(1000);   // end of drift correction
  msec_delay(40);
  dos_nosound();
}

	/* These routines implement the drawing and erasing */
	/* of the calibration and drift correction targets  */

void cal_target_beep(void)		 /* used to signal new target */
{
  cal_done_beep(0);
}



/*********** CAMERA IMAGE DISPLAY (EXPTSPPT FUNCTIONS) **********/


		/* load VGA DAC color entry */
		/* use direct-access as some BIOS calls are very slow */
		/* palette values range from 0-63 */
static void set_dac_entry(int slot, unsigned r, unsigned g, unsigned b)
{
  outportb(0x3c8,slot);  /* set DAC entry */
  outportb(0x3c9,r);     /* load RGB triplet */
  outportb(0x3c9,g);
  outportb(0x3c9,b);
}

	/* setup for image display   */
	/* gives expected image size <width>,<height>*/
	/* may be called repeatedly with differnt legend */
	/* return -1 if fails, else 0 */
INT16 setup_image_display(INT16 width, INT16 height)
{
  set_image_graphics();
  set_dac_entry(0x80, 0,15,20);    /* clear screen to cyan */
  _fmemset(MK_FP(0xA000,0), 0x80, 64000L);

  return 0;
}

	/* supplies camera image title data */
	/* called whenever data changes     */
void image_title(INT16 threshold, char *cam_name)
{
  char legend[40];

  sprintf(legend, " Cam:%s  Thr:% 4d ", cam_name, threshold);
  gotoxy(20-strlen(legend)/2, 20);
  printf("%s", legend);
}

	/* used to display an image line */
	/* you are passed an array of bytes containing picture colors */
void draw_image_line(INT16 width, INT16 line, INT16 totlines, byte *pixels)
{
  byte _far *video = MK_FP(0xA000, (20+line)*320 + 64);   /* video address of line start */

  _fmemcpy(video, pixels, width);
}


	/* gives a set of RGB colors to set up for next image */
void set_image_palette(INT16 ncolors, byte r[], byte g[], byte b[])
{
  short i;

  for(i=0;i<ncolors;i++)
    {
      set_dac_entry(i, r[i]>>2, g[i]>>2, b[i]>>2);
    }
}

	/* end of image display */
void exit_image_display(void)
{
  reinit_graphics();
  clear_display(target_background_color);
}

/******** RECORD ABORT HANDLER (EXPTSPPT FUNCTIONS) ********/

	/* called if abort of record: used to hide display from subject */
void record_abort_hide(void)
{
  clear_display(target_background_color);
}


