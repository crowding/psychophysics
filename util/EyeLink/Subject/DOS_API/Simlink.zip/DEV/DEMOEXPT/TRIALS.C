/*  SAMPLE EXPERIMENT USING EYELINK SIMTSR FOR DOS */
/*  13 December 1997 by Dave Stampe                */
/*  Copyright (c) 1996-1998 SR Research Ltd.       */

/* This file: Sequences and sets up trials for sample experiment */

#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <string.h>

#include "eyelink.h"
#include "exptsppt.h"

#include "demoexpt.h"  /* header file for this experiment */

/******************** SET UP A TRIAL ***********************/

			/* sample stimulus set */
char far *words[4] = { "One",
		   "Two",
		   "Three",
		   "Four" };

#define MAX_TRIAL_TIME 20000L	/* maximum trial duration: 20 seconds */

	/* This function sets up and executes a trial.              */
	/* It first places a title on th EyeLink display,           */
	/* and a "TRIALID" message to mark the trial and conditions.*/
	/* Then it executes the trial and returns a result code.    */

int do_trial(int trialnum)
{
     /* This supplies a title at the bottom of the eyetracker display */
  eyecmd_printf("record_status_message 'TRIAL %d text=%s' ",
					trialnum, words[trialnum-1]);

	   /* Always send this message before starting to record.  */
	   /* It marks the start of the trial and also             */
	   /* contains trial condition data required for analysis. */
  eyemsg_printf("TRIALID T%d %d %s",
		 trialnum, trialnum, words[trialnum-1]);

	   /* DRAW TRACKER REFERENCE GRAPHICS */
	   /* These give feedback to operator */
  set_offline_mode();     /* offline mode for drawing graphics to tracker */

  eyecmd_printf("clear_screen 0");               /* clear tracker display */
  eyecmd_printf("draw_box %d %d %d %d  %d",      /* draw stimulus box */
		     320-20, 240-12, 320+20, 240+12, 7);

  return record_trial(words[trialnum-1], MAX_TRIAL_TIME);
}



/****************** BLOCK LOOP ******************/

#define NTRIALS 4

	/* This code sequences trials within a block  */
	/* It calls do_trial() to execute a trial,    */
	/* then interperts result code.               */
	/* It places a result message in the EDF file */
	/* This example allows trials to be repeated  */
	/* from the tracker ABORT menu.               */

	/* Executes trial, processes error or result codes */
int run_trials(void)
{
  int i;
  int trial;
		/* PERFORM CAMERA SETUP, CALIBRATION. */
  do_tracker_setup();

				/* loop through trials */
  for(trial=1;trial<=NTRIALS;trial++)
    {
      if(eyelink_is_connected()==0)    /* drop out if link closed */
	{
	  return ABORT_EXPT;
	}

				/* RUN THE TRIAL */
      i = do_trial(trial);

      switch(i)                 /* REPORT ANY ERRORS */
	{
	  case ABORT_EXPT:        /* handle experiment abort or disconnect */
	    eyemsg_printf("EXPERIMENT ABORTED");
	    return ABORT_EXPT;
	  case REPEAT_TRIAL:	  /* trial restart requested */
	    eyemsg_printf("TRIAL REPEATED");
	    trial--;
	    break;
	  case SKIP_TRIAL:	   /* skip trial */
	    eyemsg_printf("TRIAL ABORTED");
	    break;
	  case TRIAL_OK:
	    eyemsg_printf("TRIAL OK");
	    break;
	  default:
	    eyemsg_printf("TRIAL ERROR");
	    break;
	}
    }      /* end of trial loop */

  playback_trial();   /* DEMONSTRATE DATA PLAYBACK */
  return 0;
}

