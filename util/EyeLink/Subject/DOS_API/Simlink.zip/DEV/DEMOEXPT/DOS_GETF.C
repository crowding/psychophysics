/*  MS-DOS PROGRAMMING SUPPORT FOR EYELINK EXPERIMENTS */
/*  Updated: 13 December 1997 by Dave Stampe           */
/*  Copyright (c) 1996-1998, SR Research Ltd.          */

/* Basic file xfer, with error checking	*/
/* DOS PLATFORM (generic) file xfer, uses text feedback */

/* This module is for user applications   */
/* Use is granted for non-commercial      */
/* applications by Eyelink licencees only */

/************** WARNING **************/
/*                                   */
/* UNDER NO CIRCUMSTANCES SHOULD     */
/* PARTS OF THIS FILE BE COPIED OR   */
/* COMBINED.  This will make your    */
/* code impossible to upgrade to new */
/* releases in the future, and       */
/* SR Research will not give tech    */
/* support for reorganized code.     */
/*                                   */
/* This file should not be modified. */
/* If you must modify it, copy the   */
/* entire file with a new name, and  */
/* change the the new file.          */
/*                                   */
/************** WARNING **************/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "eyelink.h"
#include "exptsppt.h"


	/* Add extension but drop directory, drive */
	/* FORCE enforces ext. replacement, else only if missing */
static void add_extension(char *in, char *out, char *ext, int force)
{
   char *c;

   strcpy(out, in);
   c = out;
   while(*c)
     {
       if(*c=='.')
	 {
	   if(!force) return;
	   *c = 0;
	   break;
	 }
	c++;
     }
   strcat(out, ".");
   strcat(out, ext);
}


static byte file_buf[550];	/* buffer for file data block */

	/* File transfer uses the TSR to start, end */
	/* and to get data blocks.  This code is very simple, */
	/* but has a lot of error checks and messages. */
INT32 receive_data_file(char *src, char *dest, INT16 dest_is_path)
{
  FILE   *out = NULL;	/* our file: NULL means it's not open (first block) */
  INT32  file_size;     /* total file size */
  UINT32 ftotal;        /* total received so far */
  INT32  size;
  int retries;
  char fname[150];   /* final save path */
  char fsrc[50];     /* stripped source file name */

  file_size = start_file_receive(src, fsrc, 0);
  if(file_size < 0) return file_size;

  strcpy(fname, dest);
  if(dest && dest[0])
    {
      if(dest_is_path)
	strcat(fname, fsrc);
      else
	strcpy(fname, dest);
    }
  else strcpy(fname, fsrc);

  printf("\nXFER: Transferring '%s'->'%s' (%ld bytes)\n", fsrc, fname, file_size);

  ftotal = 0;
  out = fopen(fname, "wb");
  if(!out)
    {
      printf("XFER: Cannot create %s\n", fname);
      eyelink_end_file_transfer();    /* abort transfer and exit */
      return -3;
    }

  retries = 0;
  while(1)		    /* loop to receive the file */
    {
      size = receive_file_block(ftotal, file_buf);

      if(size < 0)  	     /* handle errors */
	{                    /* transfer aborted or too many errors */
	  if(size==FILE_XFER_ABORTED || retries>5)
	    {
	      printf("\nXFER: Transfer aborted.\n");
	      eyelink_end_file_transfer();        /* abort transfer */
	      fclose(out);
	      return size;
	    }
	  printf("\nXFER: offset=%ld, Error %d, retrying\n", ftotal, size);
	  retries++;
	  continue;
	}
						 /* write data block */
      if((size_t)size != fwrite(file_buf, 1, size, out))
	{				 /* error if all not written */
	  printf("\nXFER: Error writing to %s\n", fname);
	  eyelink_end_file_transfer();   /* abort transfer */
	  fclose(out);
	  return -4;
	}
      ftotal += size;
      printf("XFER: %1.0f% transferred\r",
		      (100.0*ftotal)/(float)file_size);
      retries = 0;
			      /* if only partial block, it was last */
      if(size < FILE_BLOCK_SIZE)
	{
	  printf("XFER: 100% transferred\n");
	  printf("XFER: Sucessfully copied file!\n");

	  fclose(out);	   /* close file */
	  return ftotal;
	}
    }
}

