/*  SAMPLE EXPERIMENT USING EYELINK SIMTSR FOR DOS */
/*  13 December 1997 by Dave Stampe                */
/*  Copyright (c) 1996-1998 SR Research Ltd.       */

/*   This file can serve as a start       */
/*   for programming most experiments     */

/* This file: Simple recording trial for sample experiment */

#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <string.h>

#include "eyelink.h"

#include "exptsppt.h"

#include "demoexpt.h"  /* header file for this experiment */

#if (defined(__BORLANDC)||defined(__TURBOC__))
  #define TEXTPOSN(r,c) gotoxy(r,c)
#else
  #define TEXTPOSN(c,r) _settextposition(r,c)
#endif


/********* PERFORM AN EXPERIMENTAL TRIAL  *******/

	/* Run a single trial. */
	/* We first perform a drift correction */

	/* We start recording at least 100 msec before any */
	/* changes are made to the screen, and continue for */
	/* 100 msec after the subject responds, to ensure */
	/* we get all the data. */

	/* We draw a target for the drift correction and keep it */
	/* around till we display our final image. */
	/* During recording, we draw any new graphics, */
	/* We then wait for a button press. */

	/* SUGGESTED MESSAGES: */
	/* We always start each trial with a "TRIALID" message, */
	/* containing all data needed to analyze the trial */
	/* (parameters, trial numer, condition, etc.). */
	/* During the trial, we report events (usually display */
	/* of stimuli) with messages, the first word of which */
	/* is unique.  These message serve top timestamp the event. */
	/* We report the result of the trial with a "TRIAL_RESULT" */
	/* message, containing any result data such as */
	/* the response button pressed or time-out. */

	/* We end with a "TRIAL" message (in this case produced */
	/* in run_trials() ) which contains trial number and a */
	/* result string: we will keep trial data if the result was "OK". */


static void end_trial(void)
{
  clear_display(target_background_color);    /* hide display */
  msec_delay(100);     /* record additional 100 msec of data */
  stop_recording();
}


	/* This demo simply prints out a word at screen center */
	/* It will end when a button is pressed, */
	/* or after <time_limit> milliseconds */

int record_trial(char *word, UINT32 time_limit)
{
  UINT32 trial_start;	/* trial start time (for timeout) */
  UINT32 draw_time;	/* time to draw stimulus (DEBUG)  */

  int button;		/* the button pressed (0 if timeout) */
  int error;

	   /* DO PRE-TRIAL DRIFT CORRECTION */
	   /* We repeat if ESC key pressed to do setup. */
	   /* This might also erase any pre-drawn graphics. */
  while(1)
    {              /* Check link often so we don't lock up if tracker lost */
      if(!eyelink_is_connected()) return ABORT_EXPT;

	   /* DRIFT CORRECTION */
	   /* In this case, we draw the target ourselves.  */
	   /* We could also let do_drift_correct() draw it */
	   /* but this would erase the screen afterwards.  */
      clear_display(target_background_color);
      draw_cal_target(320,240);
	       /* 3rd argument  is 0 to NOT draw target */
      error = do_drift_correct(320,240, 0, 1);

	       /* repeat if ESC was pressed to access Setup menu */
      if(error!=27) break;
    }

	    /* Start data recording to EDF file, no link data */
	    /* First data will be recorded 10-100 msec later  */
	    /* (delay depends on previous tracker mode).      */
  error = start_recording(1,1,0,0);
  if(error != 0) return error;

  msec_delay(100);	/* record for 100 msec before displaying stimulus */

	  /* DISPLAY OUR IMAGE TO SUBJECT */
	  /* The faster it's displayed, the better! */
	  /* Our graphics here are simple and fast */
	  /* Real stimuli might require the screen to be blanked */
	  /* or drawing on a background page before recording starts. */

  clear_display(target_background_color); /* clear display */
  vga_retrace_wait();             /* start drawing at start of refresh */
  draw_time = current_time();
  TEXTPOSN(40-strlen(word)/2, 15);  /* draw stimulus word */
  printf("%s", word);
  draw_time = current_time() - draw_time; /* compute draw time (for debug) */

  vga_retrace_wait();            /* wait for end of refresh before marking */
  eyemsg_printf("DISPLAY ON");	 /* message for RT computation */
  eyemsg_printf("SYNCTIME");	 /* message for EDFVIEW time plot */
  trial_start = current_time();  /* record display onset time  */

  eyelink_flush_keybuttons(0);   /* reset keys and buttons from tracker */
  while(getkey());		 /* dump any pending local keys */

  while(1) /* loop till timeout or response */
    {
				 /* Check recording status */
      if((error=check_recording())!=0) return error;

				 /* Check for trial timeout */
      if(current_time() > trial_start+time_limit)
	{
	  eyemsg_printf("TIMEOUT");     /* log the timeout */
	  end_trial();
	  button = 0;        /* trial result is 0 if timeout */
	  break;             /* exit loop */
	}
			     /* LOCAL KEYBOARD EXIT */
      if(getkey()==ESC_KEY)  /* if ESC key pressed, abort trial locally */
	{
	  end_trial();
	  return SKIP_TRIAL;   /* return code to skip trial */
	}
			     /* BUTTON RESPONSE TEST */
			     /* read button from eyetracker */
      button = eyelink_last_button_press(NULL);
      if(button!=0)          /* button number, or 0 if none */
	{
	  eyemsg_printf("ENDBUTTON %d", button); /* log the button */
	  end_trial();
	  break;               /* exit loop */
	}
    }
			   /* report result: 0=timeout, else button */
  eyemsg_printf("TRIAL_RESULT %d", button);

			   /* HANDLE SPECIAL EXIT CONDITIONS */
  return check_record_exit();
}


