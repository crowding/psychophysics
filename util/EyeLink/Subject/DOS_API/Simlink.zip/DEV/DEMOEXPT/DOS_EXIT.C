/*  MS-DOS PROGRAMMING SUPPORT FOR EYELINK EXPERIMENTS */
/*  Updated: 13 December 1997 by Dave Stampe           */
/*  Copyright (c) 1996-1998, SR Research Ltd.          */

/* This file: traps CTRL-C and other errors */
/* This keeps your program well-behaved.    */

/* This code has been tested with several compilers,    */
/* but exit trapping is badly implemented by some,      */
/* if your program freezes on exit try leaving this out */

/* This module is for user applications   */
/* Use is granted for non-commercial      */
/* applications by Eyelink licencees only */

/************** WARNING **************/
/*                                   */
/* UNDER NO CIRCUMSTANCES SHOULD     */
/* PARTS OF THESE FILES BE COPIED OR */
/* COMBINED.  This will make your    */
/* code impossible to upgrade to new */
/* releases in the future, and       */
/* SR Reseach will not give tech     */
/* support for reorganized code.     */
/*                                   */
/* This file should not be modified. */
/* If you must modify it, copy the   */
/* entire file with a new name, and  */
/* change the the new file.          */
/*                                   */
/************** WARNING **************/


#include <stdlib.h>
#include <stdio.h>
#include <dos.h>
#include <signal.h>

#include "eyelink.h"

#include "exptsppt.h"

/******** ERROR TRAPS  ********/

void (far *old_sigfpe_handler)(int) = NULL;  /* old handlers */
void (far *old_sigint_handler)(int) = NULL;
void (far *old_sigill_handler)(int) = NULL;
void (far *old_sigsegv_handler)(int) = NULL;
void (far *old_sigterm_handler)(int) = NULL;


int error_traps_set = 0;    /* 1 if error traps enabled */

void reset_error_traps(void)          /* restore abnormal-exit traps */
{
  if(!error_traps_set) return;

  if(old_sigfpe_handler)
    signal(SIGFPE, old_sigfpe_handler);
  else
    signal(SIGFPE, SIG_DFL);

  if(old_sigint_handler)
    signal(SIGINT, old_sigint_handler);
  else
    signal(SIGINT, SIG_DFL);

  if(old_sigill_handler)
    signal(SIGILL, old_sigill_handler);
  else
  signal(SIGILL, SIG_DFL);

  if(old_sigsegv_handler)
    signal(SIGSEGV, old_sigsegv_handler);
  else
  signal(SIGSEGV, SIG_DFL);

  if(old_sigterm_handler)
    signal(SIGTERM, old_sigterm_handler);
  else
  signal(SIGTERM, SIG_DFL);

}


void report_exit_error(int sig)       /* report the error type for debugging */
{
  union REGS r;
  char far *msg;

  switch(sig)
    {
      case SIGFPE:
	msg = "\nSIGFPE: Math error\n";
	break;
      case SIGINT:
	msg = "\nSIGINT: CTRL-C pressed\n";
	break;
      case SIGILL:
	msg = "\nSIGILL: Illegal instruction\n";
	break;
      case SIGSEGV:
	msg = "\nSIGSEGV: Protection Fault\n";
	break;
      case SIGTERM:
	msg = "\nSIGTERM: Program terminated\n";
	break;
      default:
	msg = "\nTerminated with unknown error\n";
	break;
    }

  while( *msg )      	/* output routine that is safe to call during error exit */
    {
      r.h.ah = 0x0e;
      r.h.al = *msg++;
      int86( 0x10, &r, &r );
   }
}

extern void reset_graphics(void);
extern void shutdown_system(void);

void exit_error_trap(int sig)   /* handles crash or CTRL-C exit */
{                          /* <sig> is the type of error */
  if(error_traps_set)
    {                      /* this handles first pass in possible loops */
      shutdown_system();
      report_exit_error(sig);
      raise(sig);          /* tell older error traps about it */
      exit(1);
    }
  else
    {
      reset_graphics();    /* This handles any extra loops */
      report_exit_error(sig);
    }
}


void set_error_traps(INT16 ignore_break)
{
  if(!ignore_break)
    old_sigint_handler = signal(SIGINT, exit_error_trap);
  else
    old_sigint_handler = signal(SIGINT, SIG_IGN);

  old_sigfpe_handler = signal(SIGFPE, exit_error_trap);  /* trap abnormal exit */
  old_sigill_handler = signal(SIGILL, exit_error_trap);
  old_sigsegv_handler = signal(SIGSEGV, exit_error_trap);
  old_sigterm_handler = signal(SIGTERM, exit_error_trap);

  atexit(reset_error_traps);
  error_traps_set = 1;
}

