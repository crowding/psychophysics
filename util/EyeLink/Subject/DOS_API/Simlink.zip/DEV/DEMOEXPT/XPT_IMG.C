/* EYELINK PORTABLE EXPT SUPPORT    */
/* (c) 1996-1998, SR Research Ltd.  */
/*     8 June '97 by Dave Stampe    */
/*     For non-commercial use only  */
/*				    */
/* Camera image display: uses       */
/* 4-bit packed format (mode 1)     */

/* This module is for user applications   */
/* Use is granted for non-commercial      */
/* applications by Eyelink licencees only */

/************** WARNING **************/
/*                                   */
/* UNDER NO CIRCUMSTANCES SHOULD     */
/* PARTS OF THESE FILES BE COPIED OR */
/* COMBINED.  This will make your    */
/* code impossible to upgrade to new */
/* releases in the future, and       */
/* SR Research will not give tech    */
/* support for reorganized code.     */
/*                                   */
/* This file should not be modified. */
/* If you must modify it, copy the   */
/* entire file with a new name, and  */
/* change the the new file.          */
/*                                   */
/************** WARNING **************/


#include <stdlib.h>

#include "eyelink.h"

#include "exptsppt.h"


/********* SET IMAGE PALETTE *********/

static byte rcolors[16], gcolors[16], bcolors[16];

	/* EyeLink palette uses description rather than table */
	/* as this allows palette translation (i.e. for Windows) */
	/* Has grey-scale ramp plus up to 6 special colors */
static void load_palette(IMAGE_PALDATA *p)
{
  unsigned i;
			/* load data from palette def: */
  unsigned int rmini = p->rfirst_color;  /* ramp low value slot */
  unsigned int rmin  = p->rfirst_brite;  /* ramp low value brightness */
  unsigned int rmaxi = p->rlast_color;   /* ramp high value slot */
  unsigned int rmax  = p->rlast_brite;   /* ramp high value brightness */
  unsigned int nspecial = p->nspecial;	 /* number of special colors */

  for(i=rmini;i<=rmaxi;i++)    	/* assign grey-scales in ramp */
	  rcolors[i] =
	   gcolors[i] =
	    bcolors[i] = rmin + ((i-rmini)*(rmax-rmin))/(rmaxi-rmini);

  for(i=0;i<nspecial;i++)	/* assign special colors */
    {
      rcolors[ p->spcolors[i].index ] = p->spcolors[i].r;
      gcolors[ p->spcolors[i].index ] = p->spcolors[i].g;
      bcolors[ p->spcolors[i].index ] = p->spcolors[i].b;
    }

  set_image_palette(16, rcolors, gcolors, bcolors);
}



/********* TRACKER CAMERA IMAGE DISPLAY *******/


static byte linebuf[250];   	     /* buffer for image line data */
static IMAGE_PALDATA pal;            /* buffer for the palette data */
static int last_threshold = -1;

static char *cam_names[4] = { "",          /* names for cameras */
		              " LEFT  ",
		              " HEAD  ",
		              " RIGHT " };

	/* This handles display of the EyeLink camera images */
	/* While in imaging mode, it contiuously requests */
	/* and displays the current camera image */
	/* It also displays the camera name and threshold setting */
	/* Keys on the subject PC keyboard are sent to the tracker */
	/* so the experimenter can use it during setup. */
	/* It will exit when the tracker leaves */
	/* imaging mode or disconnects */

INT16 image_mode_display(void)
{
  UINT32 t; 			/* for time-out tests */
  int i;
  INT16 type, width, height;    /* image data */
  int force_first = 1;          /* used to force palette load for first image */

  last_threshold = -1;
				/* WHILE TRACKER IS IN IMAGE MODE */
  while(eyelink_current_mode() & IN_IMAGE_MODE)
    {                           /* ask for 4-bit, full-size image */
      eyelink_request_image(1, 190, 120);

				/* WAIT FOR THE FIRST IMAGE DATA */
      t = current_time();
      while(eyelink_current_mode() & IN_IMAGE_MODE)
       {
	 if(t+250 < current_time()) break;  /* too long: try again */
	 if(eyelink_image_status()) break;  /* do we have start of image? */
	 if(echo_key()==TERMINATE_KEY) 	    /* send any keys to tracker */
	   {
             exit_image_display();
	     return TERMINATE_KEY;
	   }
       }
				/* get image size data */
				/* restart if we didn't get first block */
      if(eyelink_image_data(&width, &height, &type) <0) continue;

				/* SET THE IMAGE PALETTE IF CHANGED */
      i = eyelink_get_palette(&pal);	/* get palette data */
      if(force_first)                   /* first image: start up display */
	{
	  force_first = 0;
	  if(setup_image_display(width, height)) break;
	  load_palette(&pal);
          image_title(pal.threshold, cam_names[pal.camera]);
	}
      else if(i==1)                  	/* camera/palette changed */
        {
          load_palette(&pal);
          image_title(pal.threshold, cam_names[pal.camera]);
	}
      else if(last_threshold != pal.threshold)   /* threshold changed */
        {
          last_threshold = pal.threshold;
          image_title(pal.threshold, cam_names[pal.camera]);
        }
        			/* RECIEVE AND DISPLAY THE IMAGE LINES */
      t = current_time();
      while(eyelink_current_mode() & IN_IMAGE_MODE)
       {
	 if(t+250 < current_time()) break; /* too long: rcve has stalled */
	 echo_key();			   /* send any keys to tracker */
	 i = eyelink_get_line(linebuf);    /* get an image line */
	 if(i<0) break;                    /* restart if receive aborted */
	 if(i>0)
	   {
	     int j;
	     byte unpacked[400];
	     byte *v = unpacked;
	     byte *buf = linebuf;
	     for(j=0;j<width-1;j+=2)    /* unpack: 2 pixels per byte */
	       {
		 *v++ = (*buf)>>4;
		 *v++ = (*buf++) & 15;
	       }
	     if(width & 1)              /* do last pixel for ODD width */
                *v++ = (*buf)>>4;
	     draw_image_line(width, i, height, unpacked);
	   }
	 if(i==height) break;	  /* last image line: start next image */
       }
   }

  exit_image_display();
  return 0;
}

