/*    SIMLINK TSR SUPPORT              */
/*  (c) 1995-1998 by SR Research Ltd.  */
/*  29 May '97 by Dave Stampe          */
/*                                     */
/*  SIMLINK TSR C INTERFACE v2.0       */
/* This code implements standard       */
/* SIMLINK functions through TSR calls */
/* MS-DOS REAL MODE VERSION.           */

/* This module is for user applications   */
/* Use is granted for non-commercial      */
/* applications by Eyelink licencees only */


/************** WARNING **************/
/*                                   */
/* UNDER NO CIRCUMSTANCES SHOULD     */
/* PARTS OF THIS FILE BE COPIED OR   */
/* COMBINED.  This will make your    */
/* code impossible to upgrade to new */
/* releases in the future, and       */
/* SR Research will not give tech    */
/* support for reorganized code.     */
/*                                   */
/* This file should not be modified. */
/* If you must modify it, copy the   */
/* entire file with a new name, and  */
/* change the the new file.          */
/*                                   */
/************** WARNING **************/


#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <ctype.h>
#include <dos.h>
#include <string.h>

#include "eye_data.h"
#include "eyelink.h"
#include "simtsr.h"
			   /* for Borland C compilers */

#if (defined(__BORLANDC)||defined(__TURBOC__))
  #define ETSR(r) {if(tsr_swi) int86((int)tsr_swi,&r,&r);}

#else                      /* for Microsoft-compatible C compilers */

//  #include <graph.h>     /* many text-display functions defined here */
  #define ETSR(r) {if(tsr_swi) _int86((int)tsr_swi,&r,&r);}

  #define FP_OFF _FP_OFF   /* other BC<-->MSC differences */
  #define FP_SEG _FP_SEG
  #define MK_FP  _MK_FP         
  #define REGS _REGS
  #define dos_setvect _dos_setvect
  #define dos_getvect _dos_getvect
  #define outportb    _outp
  #define inportb     _inp
#endif


/********* SWI SETUP ********/

UINT16 tsr_swi = 0;

void close_eyelink_system(void)
{
  union REGS r;

  if(!tsr_swi) return;

  eyelink_close(0);             /* close link if open */
  eyelink_reset_clock(0);       /* clock stop */

  r.h.ah = EYELINK_LINK_CLOSE;
  ETSR(r);
}


INT16 find_swi(void)    /* find EYELINK TSR SWI */
{
  int i,j;
  char FARTYPE *c;

  for(i=0x60;i<0x70;i++)
    {
      c = (char FARTYPE *)_dos_getvect(i);        /* get vector */
      if(c==NULL) continue;
      for(j=3;j<10;j++)                   /* check for character */
	 if(*c++=='S') break;
      if(j==10) continue;                 /* nope, none */
      if(!_fmemcmp(c,"IMLINK",7)) return i; /* check rest of string */
    }
  return 0;     /* FAILED */
}

	/* the broadcast address for the eye trackers */
ELINKADDR eye_broadcast_address;

	/* the broadcast address for the remotes */
ELINKADDR rem_broadcast_address;

	/* this node's address for the link implementation */
ELINKADDR our_address;


ILINKDATA FARTYPE *simtsr_status = NULL;

		 /* NO OPTIONS USED BY TSR SETUP */
UINT16 open_eyelink_system(UINT16 bufsize, char FARTYPE *options)
{
  union REGS r;

  tsr_swi = find_swi();
  if(!tsr_swi) return 0;

  r.h.ah = EYELINK_LINK_INIT;
  ETSR(r);
  if(r.x.ax==0) return r.x.ax;

  eyelink_reset_clock(1);       /* clock start */
  atexit(close_eyelink_system);
  simtsr_status = eyelink_data_status();
  if(simtsr_status->version != ILINKDATAVERSION) return 0;
  memcpy(our_address, simtsr_status->our_address, sizeof(ELINKADDR));
  memcpy(eye_broadcast_address, simtsr_status->ebroadcast_address, sizeof(ELINKADDR));
  memcpy(rem_broadcast_address, simtsr_status->rbroadcast_address, sizeof(ELINKADDR));
  return tsr_swi;
}

/********** LINK NODE FUNCTIONS *********/

void eyelink_set_name(char FARTYPE *name)
{
  union REGS r;

  if(!tsr_swi) return;
  r.h.ah = EYELINK_SET_NAME;
  r.x.bx = FP_OFF(name);
  r.x.dx = FP_SEG(name);
  ETSR(r);
}


	/* sends polling request to all trackers for ID */
	/* returns: OK_RESULT or LINK_TERMINATED_RESULT */
INT16 eyelink_poll_trackers(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_POLL_NODES;
  r.x.cx = 0;
  ETSR(r);
  return r.x.ax;
}

	/* sends polling request to all remotes for ID  */
	/* returns: OK_RESULT or LINK_TERMINATED_RESULT */
INT16 eyelink_poll_remotes(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_POLL_NODES;
  r.x.cx = 1;
  ETSR(r);
  return r.x.ax;
}

	/* checks for polling responses received            */
	/* returns number of responses received (0 if none) */
INT16 eyelink_poll_responses(void)
{
  if(!tsr_swi) return 0;
  return simtsr_status->poll_responses;
}

	/* gets copy of node data (in order of reception)            */
	/* <resp> selects data: 0 gets our data, 1 get first RX, etc */
	/* <data> points to buffer to receive ELINKNODE data         */
	/* returns: OK_RESULT if node data exists                    */
INT16 eyelink_get_node(INT16 resp, void FARTYPE *data)
{
  if(!tsr_swi) return 0;
  if(resp==0)
    {
      if(data)
	{
	  memcpy(((ELINKNODE *)data)->addr, simtsr_status->our_address, sizeof(ELINKADDR));
	  strcpy(((ELINKNODE *)data)->name, simtsr_status->our_name);
	}
    }
  else if(resp==-1)
    {
      if(data)
	{
	  memcpy(((ELINKNODE *)data)->addr, simtsr_status->ebroadcast_address, sizeof(ELINKADDR));
	  strcpy(((ELINKNODE *)data)->name, "eye broadcast");
	}
    }
  else if(resp==-2)
    {
      if(data)
	{
	  memcpy(((ELINKNODE *)data)->addr, simtsr_status->rbroadcast_address, sizeof(ELINKADDR));
	  strcpy(((ELINKNODE *)data)->name, "rem broadcast");
	}
    }
  else if((unsigned)resp > simtsr_status->poll_responses)
    {
      return -1;
    }
  else
    {
      if(data)
	{
	  memcpy(((ELINKNODE *)data)->addr, simtsr_status->nodes[resp-1].addr, sizeof(ELINKADDR));
	  strcpy(((ELINKNODE *)data)->name, simtsr_status->nodes[resp-1].name);
	}
    }
  return OK_RESULT;
}


	/* send an unformatted packet to another remote */
	/* <dsize> is packet size: maximum 420 bytes    */
	/* broadcast addresses are not allowed          */
	/* returns: OK_RESULT or LINK_TERMINATED_RESULT */
INT16 eyelink_node_send(ELINKADDR node, void FARTYPE *data, UINT16 dsize)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_SEND_PACKET;
  r.x.dx = FP_SEG(data);
  r.x.bx = FP_OFF(data);
  r.x.di = FP_SEG(node);
  r.x.si = FP_OFF(node);
  r.x.cx = dsize;
  ETSR(r);
  return r.x.ax;
}

	/* checks for packet from another remote               */
	/* first packet received is copied into <data> buffer  */
	/* sender address is copied into <addr> buffer         */
	/* old packets are discarded if new packet received    */
	/* returns: 0 if no data, else packet size             */
INT16 eyelink_node_receive(ELINKADDR node, void FARTYPE *data)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_RECEIVE_PACKET;
  r.x.dx = FP_SEG(data);
  r.x.bx = FP_OFF(data);
  r.x.di = FP_SEG(node);
  r.x.si = FP_OFF(node);
  ETSR(r);
  return r.x.ax;
}


/*********** TIME ***********/


UINT32 current_time()
{
  union REGS r;
  union { UINT32 l; UINT16 w[2]; } t;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_LOCAL_TIME;
  ETSR(r);
  t.w[0] = r.x.ax;
  t.w[1] = r.x.dx;
  return t.l;
}


UINT32 current_usec()
{
  union REGS r;
  union { UINT32 l; UINT16 w[2]; } t;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_LOCAL_TIME;
  ETSR(r);
  t.w[0] = r.x.cx;
  t.w[1] = r.x.si;
  return t.l;
}


UINT32 current_micro(MICRO FARTYPE *m)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_LOCAL_TIME;
  ETSR(r);
  ((UINT16 FARTYPE *)&(m->msec))[0] = r.x.ax;
  ((UINT16 FARTYPE *)&(m->msec))[1] = r.x.dx;
  m->usec = r.x.bx;
  return m->msec;
}


void msec_delay(UINT32 del)
{
  UINT32 t = current_time();

  if(!tsr_swi) return;
  while(1)
    {
      UINT32 ttc = current_time();
      if(ttc < t) break;        /* counter wrap; */
      if(ttc > t+del) break;    /* time up */
    }
}


INT16 eyelink_reset_clock(INT16 enable)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_RESET_CLOCK;
  r.h.al = (byte)enable;
  ETSR(r);
  return r.x.ax;
}


/***********/


void FARTYPE *eyelink_data_status(void)
{
  union REGS r;

  if(!tsr_swi) return NULL;
  r.h.ah = EYELINK_DATA_STATUS;
  ETSR(r);
  return MK_FP(r.x.dx, r.x.bx);
}

	/* make connection using an ELINKADDR address            */
	/* can be broadcast_address to connect to single tracker */
	/* connect will fail if <busytest> is 1                  */
	/* and tracker is connected to another remote            */
INT16 eyelink_open_node(ELINKADDR node, INT16 busytest)
{
  union REGS r;

  if(!tsr_swi) return LINK_INITIALIZE_FAILED;
  if(simtsr_status->version != ILINKDATAVERSION)
			   return WRONG_LINK_VERSION;
  r.h.ah = EYELINK_CONNECT;
  r.h.al = busytest?1:0;
  r.x.cx = 0;
  r.x.bx = FP_OFF(node);
  r.x.dx = FP_SEG(node);
  r.x.cx = 0;
  ETSR(r);
  eyelink_data_status();
  eyelink_reset_data(1);
  return r.x.ax;
}


ELINKADDR broadcast_address = {255,255,255,255,255,255,0,0};

INT16 eyelink_open(void)
{
  return eyelink_open_node(broadcast_address,0);
}


INT16 eyelink_broadcast_open(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_INITIALIZE_FAILED;
  if(simtsr_status->version != ILINKDATAVERSION)
			   return WRONG_LINK_VERSION;
  r.h.ah = EYELINK_CONNECT;
  r.x.cx = 1;
  ETSR(r);
  eyelink_data_status();
  eyelink_reset_data(1);
  return r.x.ax;
}


INT16 eyelink_dummy_open(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_INITIALIZE_FAILED;
  if(simtsr_status->version != ILINKDATAVERSION)
			   return WRONG_LINK_VERSION;
  r.h.ah = EYELINK_CONNECT;
  r.x.cx = -1;
  ETSR(r);
  eyelink_data_status();
  eyelink_reset_data(1);
  return r.x.ax;
}


INT16 eyelink_close(INT16 send_msg)
{
  union REGS r;

  if(!tsr_swi) return LINK_INITIALIZE_FAILED;
  r.h.ah = EYELINK_DISCONNECT;
  r.x.bx = send_msg;
  ETSR(r);
  return r.x.ax;
}


/********* MESSAGES AND COMMANDS *******/


			/* send command string to tracker */
			/* returns: OK_RESULT or LINK_TERMINATED_RESULT */
INT16 eyelink_send_command(char FARTYPE *text)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_SEND_COMMAND;
  r.x.bx = FP_OFF(text);
  r.x.dx = FP_SEG(text);
  ETSR(r);
  return r.x.ax;
}

		/* rtns: NO_REPLY if no result yet, 0 if OK */
		/* -1..-4 = error code */
INT16 eyelink_command_result(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_STATUS;
  ETSR(r);
  return r.x.ax;
}


			/* send command string to tracker, wait for reply */
			/* CANNOT be in TSR */
			/* returns: OK_RESULT, NO_REPLY, or error code */
INT16 eyelink_timed_command(UINT32 msec, char FARTYPE *text)
{
  INT16 i;
  UINT32 t;

  i = eyelink_send_command(text);
  if(i != OK_RESULT) return i;

  t = current_time();
  while(1)
    {
      UINT32 ttc = current_time();
      if(ttc < t) break;        /* counter wrap; */
      if(ttc > t+msec) break;    /* time up */
      i = eyelink_command_result();
      if(i!=NO_REPLY) return i;
      i = eyelink_is_connected();
      if(i==0) break;    	  // no longer connected
      if(i==-1) return OK_RESULT; // dummy connection
    }
  return NO_REPLY;
}


			/* send message string to tracker */
			/* returns: OK_RESULT or LINK_TERMINATED_RESULT */
INT16 eyelink_send_message(char FARTYPE *msg)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_SEND_MESSAGE;
  r.x.bx = FP_OFF(msg);
  r.x.dx = FP_SEG(msg);
  ETSR(r);
  return r.x.ax;
}


		/* send message string to tracker */
		/* returns: OK_RESULT or LINK_TERMINATED_RESULT */
INT16 eyelink_node_send_message(ELINKADDR node, char FARTYPE *msg)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_NODE_SEND_MESSAGE;
  r.x.bx = FP_OFF(msg);
  r.x.dx = FP_SEG(msg);
  r.x.di = FP_OFF(node);
  r.x.si = FP_SEG(node);
  ETSR(r);
  return r.x.ax;
}



		/* returns 1 if connected, 0 if not */
INT16 eyelink_is_connected(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_STATUS;
  ETSR(r);
  return r.x.dx;
}



/********* CALIBRATION, SETUP, DRIFT CORRECT *********/

		/* stop data flow */
		/* also aborts any other operations (setup, drift corr.) */
INT16 eyelink_abort(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_ABORT;
  ETSR(r);
  return r.x.ax;
}


		/* enters setup mode */
INT16 eyelink_start_setup(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_START_SETUP;
  ETSR(r);
  return r.x.ax;
}


	 /* checks if in setup/val/cal/dc mode, or if done */
INT16 eyelink_in_setup(void)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_MODE_STATUS;
  ETSR(r);
  return r.x.ax & IN_SETUP_MODE;
}


		/* checks if in setup mode, or if done */
INT16 eyelink_current_mode(void)
{
  union REGS r;

  if(!tsr_swi) return IN_DISCONNECT_MODE;
  r.h.ah = EYELINK_MODE_STATUS;
  ETSR(r);
  return r.x.ax;
}

		/* checks if in setup mode, or if done */
INT16 eyelink_tracker_mode(void)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_MODE_STATUS;
  ETSR(r);
  return r.x.bx;
}


		/* waits till new mode is finished setup */
		/* maxwait = 0 to just test flag */
		/* rtns current state of flag: 0 if not ready */
INT16 eyelink_wait_for_mode_ready(UINT32 maxwait)
{
  UINT32 t;
  union REGS r;

  if(!tsr_swi) return 0;
  t = current_time() + maxwait;
  while(t > current_time())
    {
      r.h.ah = EYELINK_STATUS;          /* first get good command reply */
      ETSR(r);
      if(r.x.ax == NO_REPLY) continue;
      if(r.x.ax != OK_RESULT) return r.x.ax;

      r.h.ah = EYELINK_MODE_STATUS;     /* then wait for mode completion */
      ETSR(r);
      if(r.h.ch) return r.h.ch;
    }
  return 0;
}


INT16 eyelink_user_menu_selection(void)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_USER_MENU_EVENT;
  ETSR(r);
  return r.x.bx;
}

		/* gets pixel X, Y of target */
		/* returns 1 if visible, 0 if not */
INT16 eyelink_target_check(INT16 FARTYPE *x, INT16 FARTYPE *y)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_TARGET_STATUS;
  ETSR(r);
  if(x) *x = r.x.bx;
  if(y) *y = r.x.dx;
  return r.x.ax;
}

		/* call to trigger acceptance of target fixation */
INT16 eyelink_accept_trigger(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_ACCEPT;
  ETSR(r);
  return r.x.ax;
}


		/* start drift correction, specify target position */
INT16 eyelink_driftcorr_start(INT16 x, INT16 y)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_START_DRIFTCORR;
  r.x.bx = x;
  r.x.dx = y;
  ETSR(r);
  return r.x.ax;
}

		/* check if drift corr done */
		/* returns OK_RESULT, ABORT_RESULT, NO_REPLY */
INT16 eyelink_cal_result(void)
{
  union REGS r;

  if(!tsr_swi) return ABORT_RESULT;
  r.h.ah = EYELINK_MODE_STATUS;
  ETSR(r);
  return r.x.dx;
}

		/* accept last drift correction */
INT16 eyelink_apply_driftcorr(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_APPLY_DRIFTCORR;
  ETSR(r);
  return r.x.ax;
}

		/* copies last message from drift correction */
INT16 eyelink_cal_message(char FARTYPE *msg)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_CAL_MESSAGE;
  r.x.bx = FP_OFF(msg);
  r.x.dx = FP_SEG(msg);
  ETSR(r);
  return r.x.ax;
}



/********* DATA MONITOR *******/

		/* resets data flow at start */
		/* if <clear> deletes all queued data */
INT16 eyelink_reset_data(INT16 clear)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_DATA_RESET;
  r.x.bx = clear;
  ETSR(r);
  return r.x.ax;
}

	/* controls what is accepted from link */
	/* use eyelink_data_start() if tracker mode must be changed */
INT16 eyelink_data_switch(UINT16 flags)
{
  simtsr_status->samples_on = (flags&RECORD_LINK_SAMPLES) ? 1 : 0;
  simtsr_status->events_on = (flags&RECORD_LINK_EVENTS) ? 1 : 0;
  eyelink_reset_data(0);
  return 0;
}


		/* makes copy of last item from eyelink_get_next_data */
		/* returns item type: */
		/* 0 if sample, -1 if none, else event code */
INT16 eyelink_get_last_data(void FARTYPE *buf)
{
  if(!tsr_swi) return -1;
  if(buf && simtsr_status->last_data_item_type>0)
       _fmemcpy(buf, &(simtsr_status->last_data_item),
		   simtsr_status->last_data_buffer_size);

  return simtsr_status->last_data_item_type;
}

		/* gets next item in queue */
		/* if "buf" is NULL, just makes copy */
		/* returns item type: */
		/* SAMPLE_TYPE if sample, 0 if none, else event code */
INT16 eyelink_get_next_data(void FARTYPE *buf)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_NEXT_DATA;
  r.x.bx = FP_OFF(buf);
  r.x.dx = FP_SEG(buf);
  ETSR(r);
  return (unsigned)r.h.al;
}

		/* waits till a sample or event is available */
		/* maxwait = 0 to just test */
		/* rtns 1 if available, 0 if not */
INT16 eyelink_wait_for_data(UINT32 maxwait,
			    INT16 samples, INT16 events)
{
  UINT32 t;
  union REGS r;

  if(!tsr_swi) return 0;
  t = current_time() + maxwait;

  while(t > current_time())
    {
      r.h.ah = EYELINK_DATA_STATUS;
      ETSR(r);
      if(samples && r.x.ax>0) return 1;
      if(events  && r.x.cx>0) return 1;
    }
  return 0;
}

		/* returns number of items remaining */
INT16 eyelink_data_count(INT16 samples, INT16 events)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_DATA_STATUS;
  ETSR(r);
  return (samples ? r.x.ax : 0) + (events ? r.x.cx : 0);
}



		/* makes copy of most recent item */
		/* returns -1 if none or error, 0 if old, 1 if new */
INT16 eyelink_newest_sample(void FARTYPE *buf)
{
  union REGS r;

  if(!tsr_swi) return -1;
  r.h.ah = EYELINK_NEWEST_SAMPLE;
  r.x.bx = FP_OFF(buf);
  r.x.dx = FP_SEG(buf);
  ETSR(r);
  return r.x.ax;
}

		/* returns LEFT_EYE, RIGHT_EYE or BINOCULAR */
		/* depending on what data is available */
		/* returns -1 if none available */
INT16 eyelink_eye_available(void)
{
  static int eye = -1;

  if(!tsr_swi) return -1;
  if(simtsr_status->packet_flags & HAVE_LEFT_FLAG)
    {
      if(simtsr_status->packet_flags & HAVE_RIGHT_FLAG) eye = BINOCULAR;
      else eye = LEFT_EYE;
    }
  else
    {
      if(simtsr_status->packet_flags & HAVE_RIGHT_FLAG) eye = RIGHT_EYE;
    }
  return eye;
}

		/* gets sample data content flag (0 if not in sample block) */
UINT16 eyelink_sample_data_flags(void)
{
  if(!tsr_swi) return 0;
  return simtsr_status->sample_data;
}

		/* gets event data content flag (0 if not in event block) */
UINT16 eyelink_event_data_flags(void)
{
  if(!tsr_swi) return 0;
  return simtsr_status->event_data;
}

		/* gets event type content flag (0 if not in event block) */
UINT16 eyelink_event_type_flags(void)
{
  if(!tsr_swi) return 0;
  return simtsr_status->event_types;
}


		/* tests for block with samples or events (or both) */
		/* rtns 1 if any of the selected types on, 0 if none on */
INT16 eyelink_in_data_block(INT16 samples,INT16 events)
{
  if(!tsr_swi) return 0;
  if(samples && simtsr_status->sample_data!=0) return 1;
  if(events  && simtsr_status->event_data!=0 ) return 1;

  return 0;
}


		/* waits till a block of samples, events, or both is begun */
		/* maxwait = 0 to just test */
		/* rtns 1 if in block, 0 if not ready */
INT16 eyelink_wait_for_block_start(UINT32 maxwait,
				   INT16 samples, INT16 events)
{
  UINT32 t;

  if(!tsr_swi) return 0;
  t = current_time() + maxwait;
  while(t > current_time())
    {
      if(samples && simtsr_status->sample_data==0) continue;
      if(events  && simtsr_status->event_data==0 ) continue;
      else return 1;
    }
  return 0;
}

		/* get sample: skips any events */
		/* rtns: 0 if none, 1 if found */
INT16 eyelink_get_sample(void FARTYPE *sample)
{
  if(!tsr_swi) return 0;
  while(eyelink_data_count(1,0))                   /* make sure sample is there */
    {
      if(eyelink_get_next_data(NULL)==SAMPLE_TYPE) /* check next item */
	{
	  eyelink_get_last_data(sample);           /* get it if it's sample */
	  return 1;
	}
    }
  return 0;    /* nope, no sample */
}


		/* start data flow */
		/* also aborts any other operations (setup, drift corr.) */
INT16 eyelink_data_start(UINT16 flags, INT16 lock_on)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_DATA_START;
  r.h.al = 1;
  r.x.bx = lock_on;
  r.x.cx = flags;
  ETSR(r);
  return r.x.ax;
}

		/* stop data flow */
		/* also aborts any other operations (setup, drift corr.) */
INT16 eyelink_data_stop(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_DATA_START;
  r.x.bx = 0;
  r.x.cx = 0;
  ETSR(r);
  return r.x.ax;
}

		/* returns data (sample-to-pixels) prescaler */
INT16 eyelink_position_prescaler(void)
{
  union REGS r;

  if(!tsr_swi) return 10;
  r.h.ah = EYELINK_STATUS;
  ETSR(r);
  return r.x.bx;
}


/******* DATA FILE PLAYBACK ********/

		/* start playback of last recording block */
		/* also aborts any other operations (setup, drift corr.) */
INT16 eyelink_playback_start(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_START_PLAYBACK;
  r.x.dx = 0;
  r.x.bx = 0;
  r.x.cx = 0;
  ETSR(r);
  return r.x.ax;
}

INT16 eyelink_playback_stop(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_STOP_PLAYBACK;
  ETSR(r);
  return r.x.ax;
}

/******* CAMERA IMAGE TRANSFER ********/

		/* rtn: 0 if sent OK, else send error code */
INT16 eyelink_request_image(INT16 type, INT16 xsize, INT16 ysize)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_REQUEST_IMAGE;
  r.x.bx = xsize;
  r.x.cx = ysize;
  r.x.dx = type;
  ETSR(r);
  return r.x.ax;
}

		/* Status: */
		/* 0 = not receiving */
		/* -1 = aborted */
		/* 1 = receiving */
INT16 eyelink_image_status(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_IMAGE_STATUS;
  ETSR(r);
  return r.h.al;
}


void eyelink_abort_image(void)
{
  union REGS r;

  if(!tsr_swi) return;
  r.h.ah = EYELINK_ABORT_IMAGE;
  ETSR(r);
}

		/* -1 = aborted/not in rcve */
		/* 0 = old palette, 1 = new palette */
		/* ptrs to size: may be NULL */
INT16 eyelink_image_data(INT16 FARTYPE *xsize, INT16 FARTYPE *ysize, INT16 FARTYPE *type)
{
  union REGS r;

  if(!tsr_swi) return -1;
  r.h.ah = EYELINK_IMAGE_STATUS;
  ETSR(r);
  if(xsize) *xsize = r.x.bx;
  if(ysize) *ysize = r.x.cx;
  if(type)  *type  = r.x.dx;
  if(r.h.al==0) return -1;
  return r.h.ah;
}

		/* get palette: always ramp definition */
		/* rtn: -1 if no image in progress */
		/* 0 if old, 1 if new palette */
INT16 eyelink_get_palette(void FARTYPE *pal)
{
  union REGS r;

  if(!tsr_swi) return -1;
  r.h.ah = EYELINK_GET_PALETTE;
  r.x.bx = FP_OFF(pal);
  r.x.dx = FP_SEG(pal);
  ETSR(r);
  return r.x.ax;
}

		/* gets unpacked line data */
		/* rtns: -1 if error/not rx */
		/* else rtns line number */
INT16 eyelink_get_line(void FARTYPE *buf)
{
  union REGS r;

  if(!tsr_swi) return -1;
  r.h.ah = EYELINK_GET_LINE;
  r.x.bx = FP_OFF(buf);
  r.x.dx = FP_SEG(buf);
  ETSR(r);
  return r.x.ax;
}


/******** TRACKER VARIABLE/TIME READ ********/

			/* send variable name to tracker for read */
			/* returns: OK_RESULT or LINK_TERMINATED_RESULT */
INT16 eyelink_read_request(char FARTYPE *text)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_READ_REQUEST;
  r.x.bx = FP_OFF(text);
  r.x.dx = FP_SEG(text);
  ETSR(r);
  return r.x.ax;
}

			/* checks for reply to eyelink_read_request() */
			/* returns OK_RESULT if we have it */
			/* copies result to buffer */
INT16 eyelink_read_reply(char FARTYPE *buf)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_READ_REPLY;
  r.x.bx = FP_OFF(buf);
  r.x.dx = FP_SEG(buf);
  ETSR(r);
  return r.x.ax;
}

			/* copies text result of command to buffer */
			/* returns message length */
INT16 eyelink_last_message(char FARTYPE *buf)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_LAST_MESSAGE;
  r.x.bx = FP_OFF(buf);
  r.x.dx = FP_SEG(buf);
  ETSR(r);
  return r.x.ax;
}

			/* sends request for tracker time update */
			/* returns: OK_RESULT or LINK_TERMINATED_RESULT */
UINT32 eyelink_request_time(void)
{
  union REGS r;

  if(!tsr_swi) return (UINT32)LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_REQUEST_TIME;
  ETSR(r);
  return r.x.ax;
}

			/* sends request for tracker time update */
			/* returns: OK_RESULT or LINK_TERMINATED_RESULT */
UINT32 eyelink_node_request_time(ELINKADDR node)
{
  union REGS r;

  if(!tsr_swi) return (UINT32)LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_NODE_REQUEST_TIME;
  r.x.bx = FP_OFF(node);
  r.x.dx = FP_SEG(node);
  ETSR(r);
  return r.x.ax;
}

			/* checks for reply to eyelink_request_time() */
			/* rtns: 0 if no reply, else time */
UINT32 eyelink_read_time(void)
{
  union REGS r;
  union { UINT32 l; UINT16 w[2]; } t;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_READ_TIME;
  ETSR(r);
  t.w[0] = r.x.ax;
  t.w[1] = r.x.dx;
  return t.l;
}




/************* KEY, BUTTON *************/

			/* reads any queued key or button events */
			/* returns: 0 if none, keycode if key, */
			/* KB_BUTTON (mods=button number) if button */
			/* mods are extra keys (shift, ctrl, alt etc) */
			/* state is KB_PRESS, KB_RELEASE, or KB_REPEAT */
UINT16 eyelink_read_keybutton(INT16 FARTYPE *mods, INT16 FARTYPE *state,
			      UINT16 FARTYPE *kcode, UINT32 FARTYPE *time)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_READ_KB;
  ETSR(r);
  if( r.x.ax==0) return 0;

  if(mods)  *mods  = r.x.cx;
  if(state) *state = r.x.si;
  if(kcode) *kcode = r.x.di;
  if(time)
    {
      ((UINT16 FARTYPE *)time)[1]  = r.x.dx;
      ((UINT16 FARTYPE *)time)[0]  = r.x.bx;
    }
  return r.x.ax;
}

			/* sends key/button state chane to tracker */
			/* code = KB_BUTTON, mods = number for button */
			/* state is KB_PRESS, KB_RELEASE, or KB_REPEAT */
INT16 eyelink_send_keybutton(UINT16 code, UINT16 mods, INT16 state)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_SEND_KB;
  r.x.bx = code;
  r.x.cx = mods;
  r.x.dx = state;
  ETSR(r);
  return r.x.ax;
}

			/* reads the currently-known state of all buttons */
			/* the bits in the returned value will be */
			/* set (1) if corresponding button is pressed */
			/* LSB is button 1, MSB is button 16 */
			/* currently only 8 buttons available */
UINT16 eyelink_button_states(void)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_BUTTONS;
  ETSR(r);
  return r.x.ax;
}

		/* returns the last button pressed (1-16, 0 if none) */
		/* if "time" is not NULL, stores time here */
UINT16 eyelink_last_button_press(UINT32 FARTYPE *time)
{
  union REGS r;

  if(!tsr_swi) return 0;
  r.h.ah = EYELINK_BUTTONS;
  ETSR(r);
  if(time)
    {
      ((UINT16 FARTYPE *)time)[1]  = r.x.dx;
      ((UINT16 FARTYPE *)time)[0]  = r.x.bx;
    }
  return r.h.cl;
}

		/* flushes any waiting keys or buttons */
		/* also updates button state flags, but these */
		/*  may not be valid for several milliseconds */
		/* if <enable_buttons> also stores buttons */
		/*  otherwise just updates for last_button_press() */
INT16 eyelink_flush_keybuttons(INT16 enable_buttons)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_FLUSH_KB;
  r.x.bx = enable_buttons;
  ETSR(r);
  return r.x.ax;
}

/************ FILE TRANSFER **********/


			/* request send of file "src" */
			/* if "", gets last data file (read "data_file_name") */
			/* rtns: 0 if OK, else send error */
INT16 eyelink_request_file_read(char FARTYPE *fname)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_REQUEST_FILE;
  r.x.bx = FP_OFF(fname);
  r.x.dx = FP_SEG(fname);
  ETSR(r);
  return r.x.ax;
}

	/* get next block of file */
	/* if *<offset> if not NULL, will be */
	/* filled with block-start offset in file */
	/* returns: negative if error */
	/* NO_REPLY if waiting for packet */
	/* else block size (0..512) */
	/* size is < 512 (can be 0) if at EOF */

INT16 eyelink_get_file_block(void FARTYPE *buf, INT32 FARTYPE *offset)
{
  union REGS r;

  if(!tsr_swi) return NO_REPLY;
  r.h.ah = EYELINK_FILE_BLOCK;
  r.x.bx = FP_OFF(buf);
  r.x.dx = FP_SEG(buf);
  ETSR(r);
  if(offset)
    {
      ((UINT16 FARTYPE *)offset)[1]  = r.x.dx;
      ((UINT16 FARTYPE *)offset)[0]  = r.x.bx;
    }
  return r.x.ax;
}

		/* requests block of file at <offset> */
		/* rtns: 0 if OK, else send error */
INT16 eyelink_request_file_block(UINT32 offset)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_FILE_REQ_BLOCK;
  r.x.dx = (unsigned)(offset>>16);
  r.x.bx = (unsigned)(offset & 0x0000FFFFL);
  ETSR(r);
  return r.x.ax;
}


			/* aborts send of file */
			/* rtns: 0 if OK, else send error */
INT16 eyelink_end_file_transfer(void)
{
  union REGS r;

  if(!tsr_swi) return LINK_TERMINATED_RESULT;
  r.h.ah = EYELINK_ABORT_FILE;
  ETSR(r);
  return r.x.ax;
}





/********* FLOATING POINT TYPE CONVERSIONS *********/

#define NO_PUPIL_PRESCALE

extern ILINKDATA FARTYPE *simtsr_status;


#define ISMISS(x)     (((unsigned)(x))==((unsigned)(MISSING)))
#define FMISS  ((float)(MISSING))
#define COPYMISS(x) ( ISMISS(x) ? FMISS : ((float)(x)) )


	/* converts prescaled integer event to floating point event */
	/* returns: 0 if conversion not required (not copied) */
	/*          1 if conversion OK                        */

int eyelink_int_to_float(void FARTYPE *idata, void FARTYPE *fdata)
{
#define is ((ISAMPLE FARTYPE *)idata)
#define fs ((FSAMPLE FARTYPE *)fdata)
#define ie ((IEVENT FARTYPE *)idata)
#define fe ((FEVENT FARTYPE *)fdata)

  switch(ie->type)
    {
      case SAMPLE_TYPE:         /* SAMPLE */
	fs->time    = is->time;
	fs->type    = SAMPLE_TYPE;
	fs->flags   = is->flags;
	fs->status  = is->status;
	fs->input   = is->input;
	fs->buttons = is->buttons;

	fs->px[0] = COPYMISS(is->px[0]);
	fs->py[0] = COPYMISS(is->py[0]);
	fs->px[1] = COPYMISS(is->px[1]);
	fs->py[1] = COPYMISS(is->py[1]);
	fs->hx[0] = COPYMISS(is->hx[0]);
	fs->hy[0] = COPYMISS(is->hy[0]);
	fs->hx[1] = COPYMISS(is->hx[1]);
	fs->hy[1] = COPYMISS(is->hy[1]);

	fs->gx[0] = ISMISS(is->gx[0]) ? FMISS : ((float)is->gx[0])/((float)simtsr_status->prescaler);
	fs->gy[0] = ISMISS(is->gy[0]) ? FMISS : ((float)is->gy[0])/((float)simtsr_status->prescaler);
	fs->gx[1] = ISMISS(is->gx[1]) ? FMISS : ((float)is->gx[1])/((float)simtsr_status->prescaler);
	fs->gy[1] = ISMISS(is->gy[1]) ? FMISS : ((float)is->gy[1])/((float)simtsr_status->prescaler);
	fs->rx = ISMISS(is->rx) ? FMISS : ((float)is->rx)/((float)simtsr_status->prescaler);
	fs->ry = ISMISS(is->ry) ? FMISS : ((float)is->ry)/((float)simtsr_status->prescaler);

      #ifdef NO_PUPIL_PRESCALE
	fs->pa[0] = ISMISS(is->pa[0]) ? FMISS : ((float)is->pa[0]);
	fs->pa[1] = ISMISS(is->pa[1]) ? FMISS : ((float)is->pa[1]);
      #else
	fs->pa[0] = ISMISS(is->pa[0]) ? FMISS : ((float)is->pa[0])/((float)simtsr_status->pprescaler);
	fs->pa[1] = ISMISS(is->pa[1]) ? FMISS : ((float)is->pa[1])/((float)simtsr_status->pprescaler);
      #endif
	fs->htype= is->htype;
	fs->hdata[0]= is->hdata[0];
	fs->hdata[1]= is->hdata[1];
	fs->hdata[2]= is->hdata[2];
	fs->hdata[3]= is->hdata[3];
	fs->hdata[4]= is->hdata[4];
	fs->hdata[5]= is->hdata[5];
	fs->hdata[6]= is->hdata[6];
	fs->hdata[7]= is->hdata[7];


	return 1;

      case MESSAGEEVENT:
	return 0;

      case BUTTONEVENT:         /* NO CONVERSION */
      case INPUTEVENT:
	return 0;

      case STARTSAMPLES:
      case STARTEVENTS:
      case ENDSAMPLES:
      case ENDEVENTS:
      default:
	return 0;

      case STARTBLINK:
      case STARTPARSE:          /* START TIME ONLY */
      case BREAKPARSE:
      case ENDPARSE:

      case ENDBLINK:            /* START, END TIME ONLY */

      case STARTSACC:           /* ALL EYE DATA */
      case STARTFIX:
      case ENDSACC:
      case ENDFIX:
      case FIXUPDATE:
	fe->time   = ie->time;
	fe->type   = ie->type;
	fe->read   = ie->read;
	fe->eye    = ie->eye;
	fe->sttime = ie->sttime;
	fe->entime = ie->entime;

	fe->hstx = ie->hstx;
	fe->hsty = ie->hsty;
	fe->henx = ie->henx;
	fe->heny = ie->heny;
	fe->havx = ie->havx;
	fe->havy = ie->havy;

	if(ie->read & READ_PUPILXY)
	  {
	    fe->gstx = ie->gstx;
	    fe->gsty = ie->gsty;
	    fe->genx = ie->genx;
	    fe->geny = ie->geny;
	    fe->gavx = ie->gavx;
	    fe->gavy = ie->gavy;
	  }
	else
	  {
	    fe->gavx = ie->gavx==MISSING ? MISSING : ((float)ie->gavx)/((float)simtsr_status->prescaler);
	    fe->gavy = ie->gavy==MISSING ? MISSING : ((float)ie->gavy)/((float)simtsr_status->prescaler);
	    fe->gstx = ie->gstx==MISSING ? MISSING : ((float)ie->gstx)/((float)simtsr_status->prescaler);
	    fe->gsty = ie->gsty==MISSING ? MISSING : ((float)ie->gsty)/((float)simtsr_status->prescaler);
	    fe->genx = ie->genx==MISSING ? MISSING : ((float)ie->genx)/((float)simtsr_status->prescaler);
	    fe->geny = ie->geny==MISSING ? MISSING : ((float)ie->geny)/((float)simtsr_status->prescaler);
	  }

	fe->supd_x = ie->supd_x==MISSING ? MISSING : ((float)ie->supd_x)/((float)simtsr_status->prescaler);
	fe->supd_y = ie->supd_y==MISSING ? MISSING : ((float)ie->supd_y)/((float)simtsr_status->prescaler);
	fe->eupd_x = ie->eupd_x==MISSING ? MISSING : ((float)ie->eupd_x)/((float)simtsr_status->prescaler);
	fe->eupd_y = ie->eupd_y==MISSING ? MISSING : ((float)ie->eupd_y)/((float)simtsr_status->prescaler);

	fe->svel = ie->svel==MISSING ? MISSING : ((float)ie->svel)/((float)simtsr_status->vprescaler);
	fe->evel = ie->evel==MISSING ? MISSING : ((float)ie->evel)/((float)simtsr_status->vprescaler);
	fe->avel = ie->avel==MISSING ? MISSING : ((float)ie->avel)/((float)simtsr_status->vprescaler);
	fe->pvel = ie->pvel==MISSING ? MISSING : ((float)ie->pvel)/((float)simtsr_status->vprescaler);

      #ifdef NO_PUPIL_PRESCALE
	fe->sta = ie->sta;
	fe->ena = ie->ena;
	fe->ava = ie->ava;
      #else
	fe->sta = ie->sta==MISSING ? MISSING : ((float)ie->sta)/((float)simtsr_status->pprescaler);
	fe->ena = ie->ena==MISSING ? MISSING : ((float)ie->ena)/((float)simtsr_status->pprescaler);
	fe->ava = ie->ava==MISSING ? MISSING : ((float)ie->ava)/((float)simtsr_status->pprescaler);
      #endif

	return 1;
    }

#undef ie
#undef fe
#undef is
#undef fs
}


	/* FLOATING-POINT DATA TYPES (ALLF_DATA type buffer) */
	/* makes copy of last item from edf_get_next_data    */
	/* returns item type:                                */
	/* SAMPLE_TYPE if sample, 0 if none, else event code */

INT16 eyelink_get_float_data(void FARTYPE *buf)
{
  int i;

  if(!tsr_swi) return 0;
  if(buf && simtsr_status->last_data_item_type>0)
    {                                               /* convert to float */
      i = eyelink_int_to_float(&(simtsr_status->last_data_item), buf);
      if(i==0)                                      /* not converted: copy */
	  _fmemcpy(buf, &(simtsr_status->last_data_item),
		   simtsr_status->last_data_buffer_size);
    }

  return simtsr_status->last_data_item_type;
}

		/* makes FSAMPLE copy of most recent sample */
		/* returns -1 if none or error, 0 if old, 1 if new */
INT16 eyelink_newest_float_sample(void FARTYPE *buf)
{
  ISAMPLE sam;
  int i;

  i = eyelink_newest_sample(&sam);
  if(i<0 || buf==NULL) return i;

  eyelink_int_to_float(&sam, buf);
  return i;
}


