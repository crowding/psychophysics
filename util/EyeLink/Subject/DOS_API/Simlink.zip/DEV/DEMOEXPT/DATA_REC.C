/*  SAMPLE EXPERIMENT USING EYELINK SIMTSR FOR DOS */
/*  13 December 1997 by Dave Stampe                */
/*  Copyright (c) 1996-1998 SR Research Ltd.       */

/* This file: Real-time data trial for sample experiment */

#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <string.h>

#include "eyelink.h"
#include "exptsppt.h"

#include "demoexpt.h"  /* header file for this experiment */

#if (defined(__BORLANDC)||defined(__TURBOC__))
  #define TEXTPOSN(r,c) gotoxy(r,c)
#else
  #define TEXTPOSN(c,r) _settextposition(r,c)
#endif


/******* SIMPLE DISPLAY OF GAZE, FIXATIONS *******/

     /* this very simple demo uses characters drawn on screen */
     /* to plot gaze position and fixations.                  */
     /* this method lets this file be is compiler independent */

static int old_gazex;	/* character position of old gaze plot */
static int old_gazey;

	  /* erase gaze plot by printing blank */
static void erase_gazepos(void)
{
  TEXTPOSN(old_gazex, old_gazey);
  printf("�");
}

	 /* plot gaze position with box character */
static void show_gazepos(int x, int y)
{
  x = x/8;          	 /* compute position on 80x50 grid */
  y = y/8;
  if(x<0 || x>79) return;        /* not drawn if off screen */
  if(y<0 || y>49) return;
  old_gazex = x + 1;             /* compute character position */
  old_gazey = y/2 + 1;
  TEXTPOSN(old_gazex, old_gazey);
  if(y&1)
    printf("�");
  else
    printf("�");
}

	 /* plot fixation position with "F" */
static void show_fixpos(int x, int y)
{
  x = x/8;          	 /* compute position on 80x25 grid */
  y = y/16;
  if(x<0 || x>79) return;        /* not drawn if off screen */
  if(y<0 || y>24) return;
  TEXTPOSN(x, y);
  printf("F");
}


/********* PERFORM AN EXPERIMENTAL TRIAL  *******/

	/* Run a single trial, but add sample and event data. */
	/* All other operations are the same as for DEMORUN.C */

	/* ADDED FOR DATA LINK: */
	/* - set link and file data, parsing parameters for expt. */
	/* - add link data flags to eyelink_data_start() */
	/* - wait for data, check flags for which eye is available */
	/* - during recording loop: */
	/*    - check for ESC key press, abort trial */
	/*    - check for new sample, plot gaze position */
	/*    - check for ENDFIX event, use to plot fixation data */

static void end_trial(void)
{
  clear_display(target_background_color);    /* hide display */
  msec_delay(100);     /* record additional 100 msec of data */
  stop_recording();
}


int record_trial(char *word, UINT32 time_limit)
{
  UINT32 trial_start;	/* trial start time (for timeout) */
  UINT32 draw_time;	/* time to draw stimulus (DEBUG)  */
  int button;		/* the button pressed (0 if timeout) */
  int error;

  ALLF_DATA evt;	/* buffer for samples and events */
  int eye_used;		/* eye's data used for plotting */
  float x, y;		/* gaze position */

	   /* DO PRE-TRIAL DRIFT CORRECTION */
	   /* We repeat if ESC key pressed to do setup. */
	   /* This might also erase any pre-drawn graphics. */
  while(1)
    {              /* Check link often so we don't lock up if tracker lost */
      if(!eyelink_is_connected()) return ABORT_EXPT;

	   /* DRIFT CORRECTION */
	   /* In this case, we draw the target ourselves.  */
	   /* We could also let do_drift_correct() draw it */
	   /* but this would erase the screen afterwards.  */
      clear_display(target_background_color);
      draw_cal_target(320,240);
	       /* 3rd argument  is 0 to NOT draw target */
      error = do_drift_correct(320,240, 0, 1);

	       /* repeat if ESC was pressed to access Setup menu */
      if(error!=27) break;
    }

	    /* Start data recording to EDF file, */
	    /* also get sample and event data */
	    /* First data will be recorded 10-100 msec later */
	    /* (delay depends on previous tracker mode). */
  error = start_recording(1,1,1,1);
  if(error != 0) return error;

  eye_used = -1;	/* we don't know which eye yet */

  msec_delay(100);	/* record for 100 msec before displaying stimulus */

	  /* DISPLAY OUR IMAGE TO SUBJECT */
	  /* The faster it's displayed, the better! */
	  /* Our graphics here are simple and fast */
	  /* Real stimuli might require the screen to be blanked */
	  /* or drawing on a background page before recording starts. */

  clear_display(target_background_color); /* clear display */
  vga_retrace_wait();             /* start drawing at start of refresh */
  draw_time = current_time();
  TEXTPOSN(40-strlen(word)/2, 15);  /* draw stimulus word */
  printf("%s", word);
  draw_time = current_time() - draw_time; /* compute draw time (for debug) */

  vga_retrace_wait();            /* wait for end of refresh before marking */
  eyemsg_printf("DISPLAY ON");	 /* message for RT computation */
  eyemsg_printf("SYNCTIME");	 /* message for EDFVIEW time plot */
  trial_start = current_time();  /* record display onset time  */

  eyelink_flush_keybuttons(0);   /* reset keys and buttons from tracker */
  while(getkey());		 /* dump any pending local keys */

  while(1) /* loop till timeout or response */
    {
				 /* Check recording status */
      if((error=check_recording())!=0) return error;

				 /* Check for trial timeout */
      if(current_time() > trial_start+time_limit)
	{
	  eyemsg_printf("TIMEOUT");      /* log the timeout */
	  end_trial();
	  button = 0;          /* trial result is 0 if timeout */
	  break;               /* exit loop */
	}
			     /* LOCAL KEYBOARD EXIT */
      if(getkey()==ESC_KEY)  /* if ESC key pressed, abort trial locally */
	{
	  end_trial();
	  return SKIP_TRIAL;   /* return code to skip trial */
	}
			     /* BUTTON RESPONSE TEST */
			     /* read button from eyetracker */
      button = eyelink_last_button_press(NULL);
      if(button!=0)          /* button number, or 0 if none */
	{
	  eyemsg_printf("ENDBUTTON %d", button); /* log the button */
	  end_trial();
	  break;               /* exit loop */
	}
			       /* MOVE GAZE PLOT */
      if(eyelink_newest_float_sample(NULL)>0)  /* check for new sample update */
	{
	  eyelink_newest_float_sample(&evt);  /* get the sample */
	    {
	      if(eye_used != -1)   /* do we know which eye yet? */
		{
		  x = evt.fs.gx[eye_used];       /* get gaze position from sample */
		  y = evt.fs.gy[eye_used];
		  if(x!=MISSING_DATA || y!=MISSING_DATA)  /* pupil visible? */
		    {
		      erase_gazepos();     /* move gaze position */
		      show_gazepos(x,y);
		    }
		  else
		    {
		      erase_gazepos();     /* just hide if in blink */
		    }
		}
	      else
		{
		  eye_used = eyelink_eye_available();
		  switch(eye_used)
		    {
		      case RIGHT_EYE:
			eyemsg_printf("EYE_USED 1 RIGHT");
			break;
		      case BINOCULAR:
			eye_used = LEFT_EYE;
		      case LEFT_EYE:
			eyemsg_printf("EYE_USED 0 LEFT");
		      break;
		    }
		}
	    }
	}
			       /* PLOT FIXATIONS */
      if(eyelink_get_next_data(NULL) == ENDFIX)	/* check for a fixation event */
	{
	  eyelink_get_float_data(&evt);   /* get copy of it */
	  if(evt.fe.eye == eye_used)	  /* is it same eye as gaze cursor? */
	    {                             /* show average position */
	      show_fixpos(evt.fe.gavx, evt.fe.gavy);
	    }
	}
    }
			   /* report result: 0=timeout, else button */
  eyemsg_printf("TRIAL_RESULT %d", button);

			   /* HANDLE SPECIAL EXIT CONDITIONS */
  return check_record_exit();
}


