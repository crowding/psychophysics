/* EYELINK PORTABLE EXPT SUPPORT    */
/* (c) 1996-1998, SR Research Ltd.  */
/*     8 June '97 by Dave Stampe    */
/*     For non-commercial use only  */
/*				    */
/* Platform-portable part of file   */
/* transfer: specific code elsewhere*/

/* This module is for user applications   */
/* Use is granted for non-commercial      */
/* applications by Eyelink licencees only */

/************** WARNING **************/
/*                                   */
/* UNDER NO CIRCUMSTANCES SHOULD     */
/* PARTS OF THESE FILES BE COPIED OR */
/* COMBINED.  This will make your    */
/* code impossible to upgrade to new */
/* releases in the future, and       */
/* SR Research will not give tech    */
/* support for reorganized code.     */
/*                                   */
/* This file should not be modified. */
/* If you must modify it, copy the   */
/* entire file with a new name, and  */
/* change the the new file.          */
/*                                   */
/************** WARNING **************/


#include <stdlib.h>
#include <string.h>

#include "eyelink.h"
#include "exptsppt.h"

	/* strips DOS path from tracker */
	/* result is "name.ext" only    */
static void strip_dos_path(char *out, char *in)
{
  char *lgood = in;
  char *c = in;

  while(*c)
    {
      if(*c==':' || *c=='\\') lgood = c+1;
      c++;
    }
  strcpy(out, lgood);
}

	/* Prepares for file receive: gets name                  */
	/* <srch> has request name, "" for last opened EDF file  */
	/* <name> will contain actual file name,                 */
	/* set <full_name> if you want DOS path included         */
	/* Returns: negative if error, else file size            */

INT32 start_file_receive(char *srch, char *name, int full_name)
{
  INT32 file_size;     /* total file size */
  UINT32 t;            /* msec for timeout tests */
  int i;
  char fname[150] = "";

  i = eyelink_request_file_read(srch); 	/* request the file */
  if(i) return 0; 			/* Error! */

  t = current_time();
  while(1)
    {
      if(t+1000 < current_time())
	return FILE_NO_REPLY;   /* timed out */
      i = eyelink_get_file_block(fname, &file_size);
      if(i != NO_REPLY) break;	/* got file data: quit looping */
    }

  if(i != FILEDATA_SIZE_FLAG)   /* wrong block: abort transfer and exit */
    {
      eyelink_end_file_transfer();
      return FILE_XFER_ABORTED;
    }

  if(name)                      /* get name, strip off path if needed */
    {
      if(full_name)
	strcpy(name, fname);
      else
	strip_dos_path(name, fname);
    }
  return file_size;
}


	/* receive next file block, at <offset> in file             */
	/* return size of block (less than FILE_BLOCK_SIZE if last) */
	/* returns negative error code if can't receive             */
	/* FILE_XFER_ABORTED if can't recover                       */

INT32 receive_file_block(INT32 offset, void *buf)
{
  INT32 rx_offset;     /* total file size */
  UINT32 t;            /* msec for timeout tests */
  int i;

  i = eyelink_request_file_block(offset);
  if(i < 0) return i;

  t = current_time();   /* timeout reset */
  while(1)	        /* loop to wait for data */
    {
      if(t+1000L < current_time())  /* timeout test */
	 return FILE_NO_REPLY;
      i = eyelink_get_file_block(buf, &rx_offset);
      if(i != NO_REPLY) break;	    /* got data: quit looping */
    }

  if(rx_offset != offset)
     return FILE_BAD_DATA;  /* check data size, sequence */
  if(i > FILE_BLOCK_SIZE)
     return FILE_BAD_DATA;

  return i;
}

