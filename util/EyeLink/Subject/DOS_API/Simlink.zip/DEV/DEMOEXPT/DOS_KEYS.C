/*  MS-DOS PROGRAMMING SUPPORT FOR EYELINK EXPERIMENTS */
/*  Updated: 13 December 1997 by Dave Stampe           */
/*  Copyright (c) 1996-1998, SR Research Ltd.          */

/* DOS keyscan support */

/************** WARNING **************/
/*                                   */
/* UNDER NO CIRCUMSTANCES SHOULD     */
/* PARTS OF THIS FILE BE COPIED OR   */
/* COMBINED.  This will make your    */
/* code impossible to upgrade to new */
/* releases in the future, and       */
/* SR Research will not give tech    */
/* support for reorganized code.     */
/*                                   */
/* This file should not be modified. */
/* If you must modify it, copy the   */
/* entire file with a new name, and  */
/* change the the new file.          */
/*                                   */
/************** WARNING **************/


#include <stdlib.h>
#include <conio.h>
#include <ctype.h>

#include "eyelink.h"
#include "exptsppt.h"


/*********** KEYSCAN SUPPORT **********/

	/* some useful keys returned by getkey()   */
	/* on non-PC platforms, you should produce */
	/* all printable (0x20..0x7F) keys plus these codes */
	/* you should return 1 if untranslatable key pressed */
#define CURS_UP    0x4800
#define CURS_DOWN  0x5000
#define CURS_LEFT  0x4B00
#define CURS_RIGHT 0x4D00

#define ESC_KEY   0x001B
#define ENTER_KEY 0x000D

#define PAGE_UP   0x4900
#define PAGE_DOWN 0x5100


      /* Support code: non-busywait keyscan */
      /* Returns 0 if no key pressed */
      /* Returns 1 if unusable key */
      /* returns 1-255 for non-extended keys */
      /* returns 0x##00 for extended keys (##=hex code) */

      /* DOS: straightforward key scan */
UINT16 getkey(void)
{
  UINT16 c;

  if(!kbhit()) return 0;
  c = getch();
  if(c!=0) return c & 255;
//  if(!kbhit()) return JUNK_KEY;
  c = getch();
  return c<<8;
}


	/* function is similar to getkey() */
	/* but also echoes key to tracker  */
	/* implementation may require filtering leys */
UINT16 echo_key(void)
{
  UINT16 k = getkey();

  if(k!=0 && k!=1)
    eyelink_send_keybutton(k,0,KB_PRESS);
  return k;
}

