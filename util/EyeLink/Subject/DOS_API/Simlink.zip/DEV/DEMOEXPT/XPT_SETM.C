/* EYELINK PORTABLE EXPT SUPPORT    */
/* (c) 1996-1998 SR Research Ltd.   */
/*     8 June '97 by Dave Stampe    */
/*     For non-commercial use only  */
/*				    */
/*  Setup menu, drift correction    */
/*  standard user interface	    */

/* This module is for user applications   */
/* Use is granted for non-commercial      */
/* applications by Eyelink licencees only */

// This is the only source code you might want to customize
// in the xpt_xxx.C files.  This module controls the display
// and key responses during setup, calibration and drift correction.
// You might have to change it to use a different trigger input
// or to add animation to the fixation targets.

/************** WARNING **************/
/*                                   */
/* UNDER NO CIRCUMSTANCES SHOULD     */
/* PARTS OF THESE FILES BE COPIED OR */
/* COMBINED.  This will make your    */
/* code impossible to upgrade to new */
/* releases in the future, and       */
/* SR Research will not give tech    */
/* support for reorganized code.     */
/*                                   */
/* This file should not be modified. */
/* If you must modify it, copy the   */
/* entire file with a new name, and  */
/* change the the new file.          */
/*                                   */
/************** WARNING **************/


#include <stdlib.h>

#include "eyelink.h"

#include "exptsppt.h"

/* These control some of the interface options, and are usually left ON */

INT16 target_beep = 1;		  /* call beep routines on target change */

INT16 allow_local_trigger = 1;	  /* 1 to allow local spacebar -> trigger */
INT16 allow_local_control = 1;	  /* to allow all local keys -> tracker */


/********* FIXATION TARGET DISPLAY LOOP *******/

	/* This function needs some "helper" graphics */
	/* to clear the scren and draw the fixation targets. */
	/* Since C graphics are compiler-dependent, */
	/* these are found in other C source files. */

	/* While tracker is in any mode with fixation targets... */
	/* Reproduce targets tracker needs. */
	/* (if local_trigger) Local Spacebar acts as trigger */
	/* (if local_control)  Local keys echoes to tracker */
	/* RETURNS: 0 if OK, 27 if aborted */

INT16 target_mode_display(void)
{
  int target_visible = 0;	/* target currently drawn  */
  INT16 tx;		/* new target position */
  INT16 ty;

  INT16 otx=MISSING;    /* current target position */
  INT16 oty=MISSING;

  unsigned key;		/* local key pressed */
  int i;
  int result = NO_REPLY;

  setup_cal_display();
  while(getkey()) {};

			/* LOOP WHILE WE ARE DISPLAYING TARGETS */
  while(eyelink_current_mode() & IN_TARGET_MODE)
    {
      if(!eyelink_is_connected()) return -1;
      key = getkey();
				/* HANDLE LOCAL KEY PRESS */
      if(key)
	{
	  switch(key)
	    {
	      case TERMINATE_KEY:       /* breakout key code */
		clear_cal_display();
		return TERMINATE_KEY;
	      case 32:	         	/* Spacebar: accept fixation */
		if(allow_local_trigger)
		     eyelink_accept_trigger();
		break;
	      case 0: 		/* No key */
	      case JUNK_KEY: 	/* No key */
		break;
	      case ESC_KEY: if(eyelink_is_connected()==-1) goto exit; 
	      default:          /* Echo to tracker for remote control */
		if(allow_local_control)
		    eyelink_send_keybutton(key,0,KB_PRESS);
		break;
	    }
	}
	
      result = eyelink_cal_result();	
      if(result != NO_REPLY) break;
      
				/* HANDLE TARGET CHANGES */
      i = eyelink_target_check(&tx, &ty);
				/* erased or moved: erase target */
      if( (target_visible && i==0) || tx!=otx || ty!=oty)
	{
	  erase_cal_target();
	  target_visible = 0;
	}
				/* redraw if visible */
      if(!target_visible && i)
	{
	  draw_cal_target(tx, ty);
	  target_visible = 1;
	  otx = tx;		/* record position for future tests */
	  oty = ty;
	  if(target_beep)
	    cal_target_beep();	/* optional beep to alert subject */
	}
    }
    
exit:
				/* CLEAN UP ON EXIT */
  if(target_beep) cal_done_beep(result ? -1 : 0);
  if(target_visible) erase_cal_target();   /* erase target on exit */
  clear_cal_display();
  return result;
}



/********* PERFORM SETUP ON TRACKER  *******/

	/* Starts tracker into Setup Menu. */
	/* From this the operator can do camera setup, */
	/* calibrations, etc. */
	/* Pressing ESC on the tracker drops out */
	/* of all setup-related modes and exits. */

	/* All we have to do is wait till the operator */
	/* exits back to off-line mode */

INT16 do_tracker_setup(void)
{
  unsigned key;

  if(!eyelink_is_connected()) return -1;
  eyecmd_printf("heuristic_filter = ON");
  eyelink_start_setup();	     /* start setup mode */
  eyelink_wait_for_mode_ready(500);  /* time for mode change */

  setup_cal_display();
  while(getkey()) {};	     /* dump old keys */

  while(eyelink_current_mode() & IN_SETUP_MODE)
    {
      int i = eyelink_current_mode();

      if(!eyelink_is_connected()) break;
      if(i & IN_TARGET_MODE)
	{                   /* calibrate, validate, etc: show targets */
	   target_mode_display();
	}
      else if(i & IN_IMAGE_MODE)
	{                           /* display image until we're back */
	  if(image_mode_display()==TERMINATE_KEY)
	    return TERMINATE_KEY;   /* breakout key pressed */
	  else
	   setup_cal_display();
	}

      key = getkey();		/* HANDLE LOCAL KEY PRESS */
      switch(key)
	{
	  case TERMINATE_KEY:   /* breakout key code */
	    return TERMINATE_KEY;
	  case 0: 	        /* No key */
	  case JUNK_KEY:        /* No key */
	    break;
	  case ESC_KEY: if(eyelink_is_connected()==-1) goto exit; 
	  default:              /* Echo to tracker for remote control */
	    if(allow_local_control)
	       eyelink_send_keybutton(key,0,KB_PRESS);
	    break;
	}
    }
    
exit:
  exit_cal_display();
  return 0;       /* if we're in ANY other modes, we're done setup */
}



/********* PERFORM DRIFT CORRECTION ON TRACKER  *******/


	/* Performs a drift correction, with target at (x,y). */
	/* We are explicitly entering a tracker subfunction, */
	/* so we have to handle link output explicitly. */
	/* When we finish or abort the drift correction on the tracker, */
	/* it won't go to another mode until we tell it to. */
	/* For drift coorection, we can use the */
	/* drift correction result message to tell when it's done, */
	/* and what the result was. */

	/*  Here we display the target ourselves (ignore target updates), */
	/* wait for local spacebar or for operator trigger or */
	/* ESC key abort. */
	/* If operator aborts with ESC, we assume there's a setup */
	/* problem and go to the setup menu. */

	/* RETURNS: 0 if OK, 27 if Setup menu was called. */

INT16 do_drift_correct(INT16 x, INT16 y, INT16 draw, INT16 allow_setup)
{
  unsigned key;
  int result = 0;

  if(!eyelink_is_connected()) return 0;
  
  eyecmd_printf("heuristic_filter = ON");
  if(draw)
    {
      setup_cal_display();
      draw_cal_target(x,y);     /* we are told where it should be. */
    }
  while(getkey()) {};

  if(target_beep)
    cal_target_beep();

  eyelink_driftcorr_start(x, y);  /* start the drift correction */

  do {		/* wait for result */
		/* check for result of drift correction */
       if(!eyelink_is_connected()) return 0;
       result=eyelink_cal_result();

       key = getkey();
       switch(key)
	 {
	   case TERMINATE_KEY:  /* breakout code */
	     return TERMINATE_KEY;
	   case 0: 		/* no key */
	   case JUNK_KEY: 	/* no key */
	     break;
	   case 27:		/* ESC key: we flag abort from our end */
	     if(allow_local_control) result = 27;
	     if(eyelink_is_connected()==-1) result = 27;
	     break;
	   case 32: 		/* Spacebar: we trigger ourselves */
	     if(allow_local_trigger) eyelink_accept_trigger();
	     if(eyelink_is_connected()==-1) result = 0;
	     break;
	   default:
	     if(allow_local_control)
	       eyelink_send_keybutton(key,0,KB_PRESS);
	     break;
	 }
     } while(result == NO_REPLY);

  if(draw)
    {
      erase_cal_target();
      exit_cal_display();
    }

  if(result==27 || result==-1) /* Did we abort drift correction? */
    {                          /* yes: go to setup menu to fix any problems */
      if(target_beep) cal_done_beep(-1);
      if(allow_setup)
	do_tracker_setup();
      else
        set_offline_mode();
      return 27;
    }
  else
    {                   /* Otherwise, we apply the drift correction. */
      if(target_beep) cal_done_beep(1);
      eyelink_apply_driftcorr();
    }
  return result;
}



